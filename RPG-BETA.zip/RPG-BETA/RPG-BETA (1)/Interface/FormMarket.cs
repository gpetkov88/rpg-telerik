﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface
{
    public partial class FormMarket : Form
    {
        bool purchaseSuccessfull = true;
        public Player player;
        public List<Item> items;
        public FormMarket(Player player, List<Item> items)
        {
            this.player = player;
            this.items = items;
            InitializeComponent();
        }
        public void DressItem(Item item)
        {
            player.Hero.IncreaseAttack(item.AttackBonus);
            player.Hero.IncreaseDefense(item.DefenseBonus);
            player.Hero.IncreaseLife(item.LifeBonus);
            player.Hero.GoldIncreaseOrDecrease(-item.BuyCost); //minus for negative gold, beacausa auf buying
        }
        public void UndressItem (Item item)
        {
            player.Hero.IncreaseAttack(-item.AttackBonus);
            player.Hero.IncreaseDefense(-item.DefenseBonus);
            player.Hero.IncreaseLife(-item.LifeBonus);  
            player.Hero.GoldIncreaseOrDecrease(item.BuyCost);

        }
        private void CheckIfHeroGoldIsEnough(Item item)
        {
            if (player.Hero.Gold < 0)
            {
                purchaseSuccessfull = false;
                UndressItem(item);
                player.Hero.Items.Remove(item);
            }
        }
        private void checkBoxSword_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxSword.Checked = true;
        }
        private void checkBoxBreasplate_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxBreasplate.Checked = true;
        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxShield.Checked = true;
        }
        private void checkBoxRing_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxRing.Checked = true;
        }
        private void buttonBuy_Click(object sender, EventArgs e)
        {
            if (checkBoxSword.Checked)
            {
                DressItem(items[0]); //sword
                player.Hero.Items.Add(items[0]);
                CheckIfHeroGoldIsEnough(items[0]);
            }
            if (checkBoxBreasplate.Checked)
            {
                DressItem(items[1]); //breastplate
                player.Hero.Items.Add(items[1]);
                CheckIfHeroGoldIsEnough(items[1]);
            }
            if (checkBoxShield.Checked)
            {
                //player buys Shield --> nr 2 in items list
                DressItem(items[2]);
                player.Hero.Items.Add(items[2]);
                CheckIfHeroGoldIsEnough(items[2]);
            }
            if (checkBoxRing.Checked)
            {
                DressItem(items[3]);
                player.Hero.Items.Add(items[3]);
                CheckIfHeroGoldIsEnough(items[3]);
            }
            if (purchaseSuccessfull== true)
            {
                lbl.Text="purchase successfull!";
            }
            else
            {
                lbl.Text = "not enough gold";
            }
            //System.Threading.Thread.Sleep(1500);
           // this.Close();
            //SaveAndLoad.Save(player);
        }
        private void label10_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
