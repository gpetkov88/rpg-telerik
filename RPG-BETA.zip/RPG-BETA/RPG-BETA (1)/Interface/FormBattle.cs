﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface
{
    public partial class FormBattle : Form
    {
        public Player player { get; set; }
        public List<Character> Allies { get; set; }
        public List<Monster> Enemies { get;set; }

        Character currentAlly; 
        Monster currentFoe;
        int biggerTeam;

        public FormBattle(Player player, List<Monster> monsters)
        {
            InitializeComponent();

            Allies = new List<Character>();
            Enemies = new List<Monster>();

            biggerTeam = Allies.Count > Enemies.Count ? Allies.Count : Enemies.Count;
            
            this.player = player;
            this.Enemies = monsters;

            this.Allies.Add(player.Hero);
            foreach (var allyHero in player.Army)
            {
                this.Allies.Add(allyHero);
            }

            AllyTarget = 0;
            EnemyTarget = 0;

            currentAlly = Allies[AllyTarget];
            currentFoe = Enemies[EnemyTarget];

            for (int i = 0; i < Allies.Count; i++)
            {
                if (i == 0)
                {
                    var r = new RadioButton();
                    r.Checked = true;
                    r.Text = player.Name;
                    r.ForeColor = Color.Green;
                    r.CheckedChanged += new EventHandler(radioButtonsCheckChanged1);

                    var p = new ProgressBar();
                    p.Value = 99;

                    var l = new Label();
                    l.Text = "L:34|A:23|D:43";

                    groupBox1.Controls.Add(r);
                    //groupBox1.Controls.Add(l);
                    groupBox1.Controls.Add(p);
                    
                }
                else
                {
                    var r = new RadioButton();
                   
                    r.Text = Allies[i].Name;
                    r.CheckedChanged += new EventHandler(radioButtonsCheckChanged1);
                    groupBox1.Controls.Add(r);
                }
            }

            for (int i = 0; i < Enemies.Count; i++)
            {
                    RadioButton b  = new RadioButton();
                    if (groupBox2.Controls.Count == 0) b.Checked = true;
                    b.Text = Enemies[i].Name;
                    b.CheckedChanged += new EventHandler(radioButtonsCheckChanged2);      
                    groupBox2.Controls.Add(b);
            }

            
            UpdateGroupBox();
            StatUpdate(0);

            richTextBox1.AppendText("It's your turn, " + player.Name + "! Time to act quickly! ");
            richTextBox1.AppendText(Environment.NewLine);

        }

        private void radioButtonsCheckChanged1(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;

            TargetUpdateAlly();
        }

        private void radioButtonsCheckChanged2(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;

            TargetUpdateFoe();
        }

        private void UpdateGroupBox()
        {
            for (int i = 0; i < groupBox1.Controls.Count; i++)
            {
                if (i >= 1)
                {
                    groupBox1.Controls[i].Location = new Point(0, groupBox1.Controls[i - 1].Location.Y + 20);
                }
            }

            for (int i = 0; i < groupBox2.Controls.Count; i++)
            {
                if (i >= 1)
                {
                    groupBox2.Controls[i].Location = new Point(0, groupBox2.Controls[i - 1].Location.Y + 20);
                }
            }
          
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
            richTextBox1.Refresh();
            System.Threading.Thread.Sleep(200);
        }

        public void OutputColor(Color color){
            richTextBox1.ForeColor = color;
        }

        public void Output(string textLogs)
        {
            richTextBox1.AppendText(textLogs);
            richTextBox1.AppendText(Environment.NewLine);
            richTextBox1.Update();
        }

        public void Output()
        {
            richTextBox1.AppendText(Environment.NewLine);
            richTextBox1.Update();
        }

        private void FormBattle_Load(object sender, EventArgs e)
        {
           
        }

        // Accommodates the control through the RadioButtons
        public int AllyTarget { get; set; }
        public int EnemyTarget { get; set; }

        public void TargetUpdate()
        {
            TargetUpdateAlly();
            TargetUpdateFoe();
        }

        public void TargetUpdateAlly()
        {
            AllyTarget = groupBox1.Controls.IndexOf(groupBox1.Controls.OfType<RadioButton>()
                           .FirstOrDefault(n => n.Checked));

            int target = AllyTarget - deadAllies >= 0 ? AllyTarget - deadAllies : 0;

            currentAlly = Allies[target];
           
            StatUpdate(1);
        }

        int deadAllies = 0;
        int deadFoes = 0;

        public void TargetUpdateFoe()
        {
            
            EnemyTarget = groupBox2.Controls.IndexOf(groupBox2.Controls.OfType<RadioButton>()
                           .FirstOrDefault(n => n.Checked));

            int target = EnemyTarget - deadFoes >= 0 ? EnemyTarget - deadFoes : 0;

            currentFoe = Enemies[target];
            StatUpdate(2);
        }

        public void StatUpdate(int code)
        {
            if (code == 1 || code == 0)
            {
                // Output Ally information
                labelName1.Text = currentAlly.Name;
                lifeVal1.Text = currentAlly.Health.ToString();
                attVal1.Text = currentAlly.Attack.ToString();
                defVal1.Text = currentAlly.Defense.ToString();

                int remainingHP = (int)(1.0 * currentAlly.Health / currentAlly.MaxHP * 100.0);
                lifeBar1.Value = remainingHP > 0 ? remainingHP : 0;
                lifeBar1.Refresh();
                
            }

            if (code == 2 || code == 0)
            {
                // Output Enemy information
                labelName2.Text = currentFoe.Name;
                lifeVal2.Text = currentFoe.Health.ToString();
                attVal2.Text = currentFoe.Attack.ToString();
                defVal2.Text = currentFoe.Defense.ToString();

                int remainingHP = (int)(1.0 * currentFoe.Health / currentFoe.MaxHP * 100.0);
                lifeBar2.Value = remainingHP > 0 ? remainingHP : 0;
                lifeBar2.Refresh();
               
            }

        }

        int allyTurn = 0;
        int foeTurn = 0;
        int actAlly = 0;
        int actFoe = 0;
  

        // Loops the Ally indexes and returns the old one.. Acts like ++AllyIndex
        private int IncTurnAlly()
        {
            int allyLimit = Allies.Count;

            int oldTurn = allyTurn;
            allyTurn++;
            // Set to 4 manually for a good reason.
            //if (allyTurn >= Allies.Count) 
            if (allyTurn > allyLimit - 1) 
            {
                allyTurn = 0;
                
            }
    
            return oldTurn;
        }

        // Loops the Enemy indexes and returns the old one.. Acts like ++FoeIndex
        private int IncTurnFoe()
        {
            int foesLimit = Enemies.Count;

            int oldTurn = foeTurn;
            foeTurn++;
            // Set to 4 manually for a good reason.
            // if (foeTurn >= Enemies.Count) 
            if (foeTurn > foesLimit - 1) 
            {
                foeTurn = 0;     
            }

                   
            return oldTurn;
        }

        private void ButtonHIT(object sender, EventArgs e)
        {
            
            LogOutput(Allies[0].Hit(currentFoe), true);

            if (currentFoe.IsAlive == false)
            {
                richTextBox1.AppendText(currentFoe.Name + " is dead! ");
                richTextBox1.AppendText(Environment.NewLine);
                richTextBox1.Refresh();

                groupBox2.Controls[EnemyTarget].BackColor = Color.Red;
                groupBox2.Controls[EnemyTarget].Enabled = false;

                Enemies.Remove(currentFoe);
                deadFoes++;
            }

            //IncTurnAlly();
            GameTurn();
            System.Threading.Thread.Sleep(200);
        }

        
        public void LogOutput(List<string> text, bool ourTurn)
        {
            if (ourTurn)
            {
                richTextBox1.SelectionColor = Color.Green;
               
            }
            else
            {
                richTextBox1.SelectionColor = Color.Yellow;
               
            }

            for (int i = 0; i < text.Count; i++)
            {
                
                richTextBox1.AppendText(text[i]);
                StatUpdate(0);


                System.Threading.Thread.Sleep(500);
            }

            text.Clear();

            
            
        }

        bool ourTurn = true;

        private void GameTurn()
        {
          
            while (true)
            {
                // bool fairPlay = allyTurn > Enemies.Count - Allies.Count; 
                if (allyTurn < foeTurn && Enemies.Count > 0)
                {
                   // richTextBox1.AppendText("Ally turn: " + allyTurn);
                    //richTextBox1.AppendText(Environment.NewLine);
                   // richTextBox1.Refresh();

                    // Players turn!
                    if (allyTurn == 0)
                    {
                        richTextBox1.SelectionColor = Color.LightBlue;
                        richTextBox1.AppendText("It's your turn, " + player.Name + "! Time to act quickly! ");
                        richTextBox1.AppendText(Environment.NewLine);
                        
                        // Exit the loop and wait for input
                        return;
                    }
                    else
                    {
                        richTextBox1.SelectionColor = Color.Green;
                        richTextBox1.AppendText("It's " + Allies[allyTurn].Name + "'s move! ");
                        richTextBox1.AppendText(Environment.NewLine);          
                    }

                    // Else our team hits a random target

                    int target = 0;
                    do
                    {
                        target = RollADice.Roll(Enemies.Count) - 1 >= 0 ? RollADice.Roll(Enemies.Count) - 1 : 0;
                    }
                    while (Enemies[target].IsAlive == false);
                    
                    LogOutput(Allies[allyTurn].Hit(Enemies[target]), true);

                    //IncTurnAlly();

                    // Handles dead case
                    if (Enemies[target].IsAlive == false)
                    {
                        richTextBox1.AppendText(Enemies[target].Name + " is dead! ");
                        richTextBox1.AppendText(Environment.NewLine);
                        richTextBox1.Refresh();
                        groupBox2.Controls[target].ForeColor = Color.Red;
                        groupBox2.Controls[target].Enabled = false;
                        groupBox2.Refresh();

                        Enemies.RemoveAt(target);
                        deadFoes++;

                    }
                    
                    System.Threading.Thread.Sleep(200);
                    ourTurn = false;
                }
                
                if(foeTurn <= allyTurn && Allies.Count > 0)
                {
                    richTextBox1.SelectionColor = Color.Yellow;
                    richTextBox1.AppendText("It's " + Enemies[foeTurn].Name + "'s move! ");
                    richTextBox1.AppendText(Environment.NewLine);

                    int target = 0;
                    do
                    {
                        target = RollADice.Roll(Allies.Count) - 1;
                    }
                    while (Allies[target].IsAlive == false);
                    LogOutput(Enemies[foeTurn].Hit(Allies[target]), false);

                    // Handles dead case.
                    if (Allies[target].IsAlive == false)
                    {
                        richTextBox1.AppendText(Allies[target].Name + " is dead! ");
                        richTextBox1.AppendText(Environment.NewLine);
                        richTextBox1.Refresh();
                        groupBox1.Controls[target].ForeColor = Color.Red;
                        groupBox1.Controls[target].Enabled = false;

                        groupBox1.Refresh();

                        Allies.RemoveAt(target);
                        deadAllies++;
                    }

                    //IncTurnFoe();
                    
                    System.Threading.Thread.Sleep(200);
                    ourTurn = true;
                }


                if (Enemies.Count == 0)
                {
                    int goldEarned = RollADice.Roll(20);
                    player.Hero.Gold += goldEarned;
                    string message = "You win! You earn " + goldEarned + " GOLD! ";
                    DialogResult d = MessageBox.Show(message, "Battle ended!", MessageBoxButtons.OK);
                    this.Dispose();
                    this.Close();
                    break;
                    
                }

                if (Allies.Count == 0)
                {
                    DialogResult d = MessageBox.Show("You are all dead! GAME OVER! ", "Battle ended!", MessageBoxButtons.OK);
                   
                    this.Dispose();
                    this.Close();
                    break;
                }

                IncTurnAlly();
                IncTurnFoe();
            }
        }

        private void buttonCharge_Click(object sender, EventArgs e)
        {
            LogOutput(Allies[0].Charge(), true);
            IncTurnAlly();
            //ourTurn = false;
            GameTurn();
        }

        private void buttonWithdraw_Click(object sender, EventArgs e)
        {
            LogOutput(Allies[0].Withdraw(), true);
            IncTurnAlly();
            GameTurn();
        }

        private void buttonHeal_Click(object sender, EventArgs e)
        {
            LogOutput(Allies[0].Heal(), true);
            IncTurnAlly();
            GameTurn();
        }
    }
}
