﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    public class Item
    {
        private string name;
        private int buyCost;
        private int sellCost;
        private int attackBonus;
        private int defenseBonus;
        private int lifeBonus;
        private int magicBonus;
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }
        public int BuyCost
        {
            get { return this.buyCost; }
            set { this.buyCost = value; }
        }
        public int SellCost
        {
            get { return this.sellCost; }
            set { this.sellCost = value; }
        }
        public int AttackBonus
        {
            get { return this.attackBonus; }
            set { this.attackBonus = value; }
        }
        public int DefenseBonus
        {
            get { return this.defenseBonus; }
            set { this.defenseBonus = value; }
        }
        public int LifeBonus
        {
            get { return this.lifeBonus; }
            set { this.lifeBonus = value; }
        }
        public int MagicBonus
        {
            get { return this.magicBonus; }
            set { this.magicBonus = value; }
        }
        //Constuctor
        public Item()
        {

        }
        public Item(string name, int buyCost, int sellCost, int attackBonus, int defenseBonus, int lifeBonus, int magicBonus)
        {
            this.Name = name;
            this.BuyCost = buyCost;
            this.SellCost = sellCost;
            this.AttackBonus = attackBonus;
            this.DefenseBonus = defenseBonus;
            this.LifeBonus = lifeBonus;
            this.MagicBonus = magicBonus;
        }
    }
}
