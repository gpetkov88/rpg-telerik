﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    public class Monster : Character
    {
        public int Level { get; set; }

        public Monster(string name, int hp, int atack, int defense, int level)
            : base(name, hp, atack, defense)
        {
            this.Level = level;
        }
    }
}
