﻿namespace Interface
{
    partial class FormAdventure
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbMap = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.refreshStats = new System.Windows.Forms.Button();
            this.labelHPDigits = new System.Windows.Forms.Label();
            this.showGold = new System.Windows.Forms.Label();
            this.showDefense = new System.Windows.Forms.Label();
            this.showAttack = new System.Windows.Forms.Label();
            this.labelGold = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.questButton = new System.Windows.Forms.Button();
            this.marketButton = new System.Windows.Forms.Button();
            this.bFight = new System.Windows.Forms.Button();
            this.bRest = new System.Windows.Forms.Button();
            this.bMove = new System.Windows.Forms.Button();
            this.labelMove = new System.Windows.Forms.Label();
            this.labelMovesBar = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelHealth = new System.Windows.Forms.Label();
            this.progressBarHP = new System.Windows.Forms.ProgressBar();
            this.labelAttack = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBarMoves = new System.Windows.Forms.ProgressBar();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.PlayerPicture = new System.Windows.Forms.PictureBox();
            this.rbLeft = new System.Windows.Forms.RadioButton();
            this.rbRight = new System.Windows.Forms.RadioButton();
            this.rbUp = new System.Windows.Forms.RadioButton();
            this.rbDown = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pbMap)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // pbMap
            // 
            this.pbMap.BackgroundImage = global::Interface.Properties.Resources.newMap;
            this.pbMap.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbMap.Location = new System.Drawing.Point(2, 22);
            this.pbMap.Name = "pbMap";
            this.pbMap.Size = new System.Drawing.Size(960, 720);
            this.pbMap.TabIndex = 0;
            this.pbMap.TabStop = false;
            this.pbMap.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.refreshStats);
            this.panel1.Controls.Add(this.labelHPDigits);
            this.panel1.Controls.Add(this.showGold);
            this.panel1.Controls.Add(this.showDefense);
            this.panel1.Controls.Add(this.showAttack);
            this.panel1.Controls.Add(this.labelGold);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.questButton);
            this.panel1.Controls.Add(this.marketButton);
            this.panel1.Controls.Add(this.bFight);
            this.panel1.Controls.Add(this.bRest);
            this.panel1.Controls.Add(this.bMove);
            this.panel1.Controls.Add(this.labelMove);
            this.panel1.Controls.Add(this.labelMovesBar);
            this.panel1.Controls.Add(this.labelName);
            this.panel1.Controls.Add(this.labelHealth);
            this.panel1.Controls.Add(this.progressBarHP);
            this.panel1.Controls.Add(this.labelAttack);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.progressBarMoves);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(985, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 720);
            this.panel1.TabIndex = 1;
            // 
            // refreshStats
            // 
            this.refreshStats.Location = new System.Drawing.Point(56, 323);
            this.refreshStats.Name = "refreshStats";
            this.refreshStats.Size = new System.Drawing.Size(75, 23);
            this.refreshStats.TabIndex = 26;
            this.refreshStats.Text = "Refresh";
            this.refreshStats.UseVisualStyleBackColor = true;
            this.refreshStats.Click += new System.EventHandler(this.refreshStats_Click);
            // 
            // labelHPDigits
            // 
            this.labelHPDigits.AutoSize = true;
            this.labelHPDigits.Location = new System.Drawing.Point(151, 210);
            this.labelHPDigits.Name = "labelHPDigits";
            this.labelHPDigits.Size = new System.Drawing.Size(24, 13);
            this.labelHPDigits.TabIndex = 24;
            this.labelHPDigits.Text = "6/6";
            // 
            // showGold
            // 
            this.showGold.AutoSize = true;
            this.showGold.Location = new System.Drawing.Point(97, 140);
            this.showGold.Name = "showGold";
            this.showGold.Size = new System.Drawing.Size(13, 13);
            this.showGold.TabIndex = 23;
            this.showGold.Text = "0";
            // 
            // showDefense
            // 
            this.showDefense.AutoSize = true;
            this.showDefense.Location = new System.Drawing.Point(97, 117);
            this.showDefense.Name = "showDefense";
            this.showDefense.Size = new System.Drawing.Size(13, 13);
            this.showDefense.TabIndex = 22;
            this.showDefense.Text = "0";
            // 
            // showAttack
            // 
            this.showAttack.AutoSize = true;
            this.showAttack.Location = new System.Drawing.Point(97, 95);
            this.showAttack.Name = "showAttack";
            this.showAttack.Size = new System.Drawing.Size(13, 13);
            this.showAttack.TabIndex = 21;
            this.showAttack.Text = "0";
            // 
            // labelGold
            // 
            this.labelGold.AutoSize = true;
            this.labelGold.Location = new System.Drawing.Point(15, 140);
            this.labelGold.Name = "labelGold";
            this.labelGold.Size = new System.Drawing.Size(32, 13);
            this.labelGold.TabIndex = 20;
            this.labelGold.Text = "Gold:";
            this.labelGold.Click += new System.EventHandler(this.label3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Defense:";
            // 
            // questButton
            // 
            this.questButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.questButton.Location = new System.Drawing.Point(108, 519);
            this.questButton.Name = "questButton";
            this.questButton.Size = new System.Drawing.Size(67, 32);
            this.questButton.TabIndex = 17;
            this.questButton.Text = "Quest";
            this.questButton.UseVisualStyleBackColor = true;
            this.questButton.Click += new System.EventHandler(this.questButton_Click_1);
            // 
            // marketButton
            // 
            this.marketButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.marketButton.Location = new System.Drawing.Point(18, 519);
            this.marketButton.Name = "marketButton";
            this.marketButton.Size = new System.Drawing.Size(67, 32);
            this.marketButton.TabIndex = 16;
            this.marketButton.Text = "Market";
            this.marketButton.UseVisualStyleBackColor = true;
            this.marketButton.Click += new System.EventHandler(this.marketButton_Click);
            // 
            // bFight
            // 
            this.bFight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bFight.Location = new System.Drawing.Point(108, 466);
            this.bFight.Name = "bFight";
            this.bFight.Size = new System.Drawing.Size(67, 32);
            this.bFight.TabIndex = 15;
            this.bFight.Text = "Fight";
            this.bFight.UseVisualStyleBackColor = true;
            this.bFight.Click += new System.EventHandler(this.bFight_Click);
            // 
            // bRest
            // 
            this.bRest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bRest.Location = new System.Drawing.Point(18, 466);
            this.bRest.Name = "bRest";
            this.bRest.Size = new System.Drawing.Size(67, 32);
            this.bRest.TabIndex = 14;
            this.bRest.Text = "Rest";
            this.bRest.UseVisualStyleBackColor = true;
            this.bRest.Click += new System.EventHandler(this.button2_Click);
            // 
            // bMove
            // 
            this.bMove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bMove.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bMove.Location = new System.Drawing.Point(18, 415);
            this.bMove.Name = "bMove";
            this.bMove.Size = new System.Drawing.Size(157, 45);
            this.bMove.TabIndex = 13;
            this.bMove.Text = "Roll";
            this.bMove.UseVisualStyleBackColor = true;
            this.bMove.Click += new System.EventHandler(this.BMove_Click);
            // 
            // labelMove
            // 
            this.labelMove.AutoSize = true;
            this.labelMove.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMove.Location = new System.Drawing.Point(15, 383);
            this.labelMove.Name = "labelMove";
            this.labelMove.Size = new System.Drawing.Size(0, 17);
            this.labelMove.TabIndex = 12;
            // 
            // labelMovesBar
            // 
            this.labelMovesBar.AutoSize = true;
            this.labelMovesBar.Location = new System.Drawing.Point(151, 263);
            this.labelMovesBar.Name = "labelMovesBar";
            this.labelMovesBar.Size = new System.Drawing.Size(24, 13);
            this.labelMovesBar.TabIndex = 11;
            this.labelMovesBar.Text = "6/6";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(14, 55);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(55, 20);
            this.labelName.TabIndex = 10;
            this.labelName.Text = "Name";
            // 
            // labelHealth
            // 
            this.labelHealth.AutoSize = true;
            this.labelHealth.Location = new System.Drawing.Point(14, 210);
            this.labelHealth.Name = "labelHealth";
            this.labelHealth.Size = new System.Drawing.Size(41, 13);
            this.labelHealth.TabIndex = 9;
            this.labelHealth.Text = "Health:";
            // 
            // progressBarHP
            // 
            this.progressBarHP.Location = new System.Drawing.Point(18, 226);
            this.progressBarHP.Name = "progressBarHP";
            this.progressBarHP.Size = new System.Drawing.Size(157, 23);
            this.progressBarHP.TabIndex = 8;
            this.progressBarHP.Value = 100;
            this.progressBarHP.Click += new System.EventHandler(this.progressBarHP_Click);
            // 
            // labelAttack
            // 
            this.labelAttack.AutoSize = true;
            this.labelAttack.Location = new System.Drawing.Point(14, 95);
            this.labelAttack.Name = "labelAttack";
            this.labelAttack.Size = new System.Drawing.Size(41, 13);
            this.labelAttack.TabIndex = 7;
            this.labelAttack.Text = "Attack:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 263);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Moves:";
            // 
            // progressBarMoves
            // 
            this.progressBarMoves.Location = new System.Drawing.Point(18, 279);
            this.progressBarMoves.Name = "progressBarMoves";
            this.progressBarMoves.Size = new System.Drawing.Size(157, 23);
            this.progressBarMoves.TabIndex = 4;
            this.progressBarMoves.Value = 100;
            this.progressBarMoves.Click += new System.EventHandler(this.progressBarMoves_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Location = new System.Drawing.Point(64, 573);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(67, 32);
            this.button3.TabIndex = 3;
            this.button3.Text = "Inventory";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(18, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(67, 32);
            this.button1.TabIndex = 1;
            this.button1.Text = "Move";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(62, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Controls";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // PlayerPicture
            // 
            this.PlayerPicture.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.PlayerPicture.BackColor = System.Drawing.Color.Black;
            this.PlayerPicture.BackgroundImage = global::Interface.Properties.Resources.Sorcerer;
            this.PlayerPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PlayerPicture.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PlayerPicture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerPicture.Location = new System.Drawing.Point(884, 663);
            this.PlayerPicture.Name = "PlayerPicture";
            this.PlayerPicture.Size = new System.Drawing.Size(55, 55);
            this.PlayerPicture.TabIndex = 2;
            this.PlayerPicture.TabStop = false;
            this.PlayerPicture.Click += new System.EventHandler(this.PlayerPicture_Click);
            // 
            // rbLeft
            // 
            this.rbLeft.AutoSize = true;
            this.rbLeft.BackColor = System.Drawing.Color.Black;
            this.rbLeft.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbLeft.Image = global::Interface.Properties.Resources.left;
            this.rbLeft.Location = new System.Drawing.Point(809, 406);
            this.rbLeft.Name = "rbLeft";
            this.rbLeft.Size = new System.Drawing.Size(71, 50);
            this.rbLeft.TabIndex = 17;
            this.rbLeft.TabStop = true;
            this.rbLeft.UseVisualStyleBackColor = false;
            // 
            // rbRight
            // 
            this.rbRight.AutoSize = true;
            this.rbRight.BackColor = System.Drawing.Color.Black;
            this.rbRight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbRight.Image = global::Interface.Properties.Resources.right;
            this.rbRight.Location = new System.Drawing.Point(898, 406);
            this.rbRight.Name = "rbRight";
            this.rbRight.Size = new System.Drawing.Size(71, 50);
            this.rbRight.TabIndex = 18;
            this.rbRight.TabStop = true;
            this.rbRight.UseVisualStyleBackColor = false;
            // 
            // rbUp
            // 
            this.rbUp.AutoSize = true;
            this.rbUp.BackColor = System.Drawing.Color.Black;
            this.rbUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbUp.Image = global::Interface.Properties.Resources.up;
            this.rbUp.Location = new System.Drawing.Point(857, 378);
            this.rbUp.Name = "rbUp";
            this.rbUp.Size = new System.Drawing.Size(52, 50);
            this.rbUp.TabIndex = 19;
            this.rbUp.TabStop = true;
            this.rbUp.UseVisualStyleBackColor = false;
            // 
            // rbDown
            // 
            this.rbDown.AutoSize = true;
            this.rbDown.BackColor = System.Drawing.Color.Black;
            this.rbDown.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbDown.Image = global::Interface.Properties.Resources.down;
            this.rbDown.Location = new System.Drawing.Point(857, 429);
            this.rbDown.Name = "rbDown";
            this.rbDown.Size = new System.Drawing.Size(52, 50);
            this.rbDown.TabIndex = 20;
            this.rbDown.TabStop = true;
            this.rbDown.UseVisualStyleBackColor = false;
            // 
            // FormAdventure
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1276, 741);
            this.Controls.Add(this.rbLeft);
            this.Controls.Add(this.rbRight);
            this.Controls.Add(this.rbDown);
            this.Controls.Add(this.PlayerPicture);
            this.Controls.Add(this.rbUp);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pbMap);
            this.Name = "FormAdventure";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Welcome to our world";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbMap)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbMap;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelMovesBar;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelHealth;
        private System.Windows.Forms.ProgressBar progressBarHP;
        private System.Windows.Forms.Label labelAttack;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressBarMoves;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox PlayerPicture;
        private System.Windows.Forms.Label labelMove;
        private System.Windows.Forms.RadioButton rbLeft;
        private System.Windows.Forms.RadioButton rbDown;
        private System.Windows.Forms.RadioButton rbUp;
        private System.Windows.Forms.RadioButton rbRight;
        private System.Windows.Forms.Button bMove;
        private System.Windows.Forms.Button questButton;
        private System.Windows.Forms.Button marketButton;
        private System.Windows.Forms.Button bFight;
        private System.Windows.Forms.Button bRest;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelGold;
        private System.Windows.Forms.Label showGold;
        private System.Windows.Forms.Label showDefense;
        private System.Windows.Forms.Label showAttack;
        private System.Windows.Forms.Label labelHPDigits;
        private System.Windows.Forms.Button refreshStats;
    }
}