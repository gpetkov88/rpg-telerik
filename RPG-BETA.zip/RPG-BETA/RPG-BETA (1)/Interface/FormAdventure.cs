﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using WMPLib;

namespace Interface
{
    public partial class FormAdventure : Form
    {
        private WindowsMediaPlayer wplayer2;
        public Point prevCoords { set; get; }
        public Point curCoords { set; get; }
        public int roll { set; get; }

        private bool first { get; set; }
        public Player player;

        public static readonly int[,] Map = new int[,]
        {
            {9,9,4,1,1,0,0,0,0,0,4,0,0,0,0,0},
            {9,9,9,0,1,0,0,0,0,0,1,0,0,0,0,0},
            {0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0},
            {0,0,0,0,1,0,0,0,0,0,1,0,1,1,1,1},
            {0,0,0,0,1,0,0,0,0,0,1,0,1,0,0,1},
            {9,9,9,0,2,1,1,1,1,2,2,1,1,0,0,1},
            {4,9,9,0,1,0,0,0,0,1,0,0,0,0,0,1},
            {1,0,0,1,1,0,0,0,0,1,0,0,0,0,0,1},
            {1,0,0,1,0,0,0,0,0,1,3,3,3,3,3,2},
            {1,0,1,2,1,1,1,1,1,2,3,4,1,1,1,1},
            {1,0,1,0,0,0,0,0,0,2,3,0,0,0,0,0},
            {1,1,2,1,1,1,1,1,1,2,1,1,1,1,1,4}
        };
        public FormAdventure(Player player)
        {
            wplayer2 = new WMPLib.WindowsMediaPlayer();
            wplayer2.URL = @"Sounds\Time-cut.mp3";
            wplayer2.controls.play();
            wplayer2.settings.setMode("loop", true);
            this.player = player;
            InitializeComponent();
            first = false;
            rbLeft.Visible = false;
            rbRight.Visible = false;
            rbUp.Visible = false;
            rbDown.Visible = false;
            switch (player.PlayerProffesion)
            {
                case EHeroes.Amazon: PlayerPicture.BackgroundImage = Properties.Resources.Amazon;
                    break;
                case EHeroes.Archer: PlayerPicture.BackgroundImage = Properties.Resources.Archer;
                    break;
                case EHeroes.Knight: PlayerPicture.BackgroundImage = Properties.Resources.Knight;
                    break;
                case EHeroes.Sorcerer: PlayerPicture.BackgroundImage = Properties.Resources.Sorcerer;
                    break;
                default:
                    break;
            }
            InitControl();
        }

        public void InitControl()
        {
            labelName.Text = player.Name;
            showAttack.Text = player.Hero.Attack.ToString();
            showDefense.Text = player.Hero.Defense.ToString();
            showGold.Text = player.Hero.Gold.ToString();

            progressBarHP.Value = player.Hero.Health / player.Hero.MaxHP * 100;
            labelHPDigits.Text = player.Hero.Health.ToString() + "/" + player.Hero.MaxHP.ToString();
           
        }

        public void UpdateInfo()
        {
            labelName.Text = player.Name;
            showAttack.Text = player.Hero.Attack.ToString();
            showDefense.Text = player.Hero.Defense.ToString();
            showGold.Text = player.Hero.Gold.ToString();

            progressBarHP.Value = player.Hero.Health / player.Hero.MaxHP * 100;
            labelHPDigits.Text = player.Hero.Health.ToString() + "/" + player.Hero.MaxHP.ToString();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pbMap.Width = 960;
            pbMap.Height = 720; 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void HideChoice()
        {
            rbLeft.Visible = false;
            rbRight.Visible = false;
            rbUp.Visible = false;
            rbDown.Visible = false;
        }
        private void ShowChoice(int x, int y)
        {
            if (Map[y - 1, x - 1] == 2)
            {
                rbLeft.Location = new Point((x - 1) * 55, y * 55);
                rbRight.Location = new Point((x + 1) * 55, y * 55);
                rbUp.Location = new Point(x * 55, (y - 1) * 55);
                rbDown.Location = new Point(x * 55, (y + 1) * 55);

                if (x > 1 && Map[y - 1, x - 2] != 0 && CheckCurLoc(new Point(x - 1, y)))
                    rbLeft.Visible = true;
                if (x > 1 && x < 16 && Map[y - 1, x] != 0 && CheckCurLoc(new Point(x + 1, y)) && !(x + 1 == 11 && y == 10) && !(x + 1 == 11 && y == 9))
                    rbRight.Visible = true;
                if (y > 1 && Map[y - 2, x - 1] != 0 && CheckCurLoc(new Point((x), (y - 1))))
                    rbUp.Visible = true;
                if (y > 1 && y < 12 && Map[y, x - 1] != 0 && CheckCurLoc(new Point((x), (y + 1))))
                    rbDown.Visible = true;

            }
        }
        private void UnCheck()
        {
            rbLeft.Checked = false;
            rbRight.Checked = false;
            rbUp.Checked = false;
            rbDown.Checked = false;
        }
        public void LoadState()
        {
            ShowChoice(player.PlayerPosition.X/55, player.PlayerPosition.Y/55);
            CheckMovement(player.PlayerPosition.X/55, player.PlayerPosition.Y/55, player.Direction);
            this.ShowDialog();
        }
        private bool CheckPrevLoc(Point cur)
        {
            if (cur.X == prevCoords.X && cur.Y == prevCoords.Y)
                return false;
            //  if (cur != prevCoords) return true;
            else return true;
        }
        private bool CheckCurLoc(Point cur)
        {
            if (cur.X == curCoords.X && cur.Y == curCoords.Y)
                return false;
            //  if (cur != prevCoords) return true;
            else return true;
        }
        private Point CheckMovement(int x, int y, int direction)
        {
            curCoords = new Point(x, y);
            var arr = FileManager.ReadDialogList();
            for (int i = 0; i < 7; i++)
            {
                arr = FileManager.ReadDialogList();
            }

            if (x == 16 && y == 12)
            {
                DialogResult story = MessageBox.Show(arr[0], "Story", MessageBoxButtons.OK);
            }

            if (x == 11 && y == 12)
            {
                DialogResult findWisdom = MessageBox.Show(arr[1], "Find Drinking Wisdom", MessageBoxButtons.OK);
            }

            if (x == 12 && y == 10)
            {
                DialogResult atWisdom = MessageBox.Show(arr[2], "Drinking Wisdom", MessageBoxButtons.OK);
            }
            if (x == 1 && y == 7)
            {
                DialogResult atDjudjanka = MessageBox.Show(arr[3], "Djudjanka", MessageBoxButtons.OK);
            }
            if (x == 11 && y == 1)
            {
                DialogResult atIceKingdom = MessageBox.Show(arr[4], "BelotGame", MessageBoxButtons.OK);
            }
            if (x == 3 && y == 1)
            {
                DialogResult atAlica = MessageBox.Show(arr[5], "AlicaTheWarrior", MessageBoxButtons.OK);
            }
            if (x == 8 && y == 6)
            {
                DialogResult atRakiaTree = MessageBox.Show(arr[6], "TheRakiaTree", MessageBoxButtons.OK);
            }
            if (x == 8 && y == 3)
            {
                DialogResult atCaveFinal = MessageBox.Show(arr[6], "FinalBattel", MessageBoxButtons.OK);
            }

            if (y > 0 && x > 0)
            {
                if (Map[y - 1, x - 1] == 4 && first)
                {
                    Point p = new Point();
                    p = prevCoords;
                    prevCoords = new Point(curCoords.X, curCoords.Y);
                    return new Point(p.X * 55, p.Y * 55);
                }
                if (Map[y - 1, x - 1] == 2)
                {
                    if (rbLeft.Checked == true)//left
                    {
                        direction = -1;
                        if (x > 1 && Map[y - 1, x + direction - 1] != 0)
                        {
                            HideChoice();
                            UnCheck();
                            if (Map[y - 1, x - 1 + direction] == 2)
                                ShowChoice(x + direction, y);
                            prevCoords = new Point(x, y);
                            return new Point((x + direction) * 55, (y) * 55);
                        }
                    }
                    if (rbRight.Checked == true)//right
                    {
                        direction = 1;
                        if (x > 1 && Map[y - 1, x + direction - 1] != 0)
                        {
                            HideChoice();
                            UnCheck();
                            if (Map[y - 1, x - 1 + direction] == 2)
                                ShowChoice(x + direction, y);
                            prevCoords = new Point(x, y);
                            return new Point((x + direction) * 55, (y) * 55);
                        }
                    }
                    if (rbUp.Checked == true)//up
                    {
                        direction = -1;
                        if (y > 1 && Map[y + direction - 1, x - 1] != 0)
                        {
                            HideChoice();
                            UnCheck();
                            if (Map[y - 1 + direction, x - 1] == 2)
                                ShowChoice(x, y + direction);
                            prevCoords = new Point(x, y);
                            return new Point((x) * 55, (y + direction) * 55);
                        }
                    }
                    if (rbDown.Checked == true)//down
                    {
                        direction = 1;
                        if (y > 1 && Map[y + direction - 1, x - 1] != 0)
                        {
                            HideChoice();
                            UnCheck();
                            if (Map[y - 1 + direction, x - 1] == 2)
                                ShowChoice(x, y + direction);
                            prevCoords = new Point(x, y);
                            return new Point((x) * 55, (y + direction) * 55);
                        }
                    }
                    if (rbRight.Checked == false && rbLeft.Checked == false && rbUp.Checked == false && rbDown.Checked == false)
                    {
                        roll++;
                        labelMove.Text = String.Format("You have {0} more moves", roll.ToString());
                        return new Point(x * 55, y * 55);
                    }
                }
                if (Map[y - 1, x - 1] == 3)
                {
                    if (x == 15 && y == 9 && direction < 0 && prevCoords.X == 14)
                    {
                        ShowChoice(x + 1, y);
                        prevCoords = new Point(x, y);
                        return new Point((x + 1) * 55, (y) * 55);
                    }
                    if (y > 1 && Map[y + direction - 1, x - 1] == 3 && CheckPrevLoc(new Point((x), (y + direction))))
                    {
                        prevCoords = new Point(x, y);
                        return new Point((x) * 55, (y + direction) * 55);
                    }
                    if (x > 1 && Map[y - 1, x + direction - 1] == 3 && CheckPrevLoc(new Point((x + direction), (y))))
                    {
                        prevCoords = new Point(x, y);
                        return new Point((x + direction) * 55, (y) * 55);
                    }

                    if (y > 1 && Map[y - direction - 1, x - 1] == 3 && CheckPrevLoc(new Point((x), (y - direction))))
                    {
                        prevCoords = new Point(x, y);
                        return new Point((x) * 55, (y - direction) * 55);
                    }
                    if (x > 1 && Map[y - 1, x - direction - 1] == 3 && CheckPrevLoc(new Point((x - direction), (y))))
                    {
                        prevCoords = new Point(x, y);
                        return new Point((x - direction) * 55, (y) * 55);
                    }
                }

                if (y > 1 && Map[y + direction - 1, x - 1] != 0 && Map[y + direction - 1, x - 1] != 3 && CheckPrevLoc(new Point((x), (y + direction))))
                {
                    ShowChoice(x, y + direction);
                    prevCoords = new Point(x, y);
                    return new Point((x) * 55, (y + direction) * 55);
                }
                if (x > 1 && Map[y - 1, x + direction - 1] != 0 && Map[y - 1, x + direction - 1] != 3 && CheckPrevLoc(new Point((x + direction), (y))))
                {
                    ShowChoice(x + direction, y);
                    prevCoords = new Point(x, y);
                    return new Point((x + direction) * 55, (y) * 55);
                }
                if (y > 1 + direction && y - direction < 13 && Map[y - direction - 1, x - 1] != 0 && Map[y - direction - 1, x - 1] != 3 && CheckPrevLoc(new Point((x), (y - direction))))
                {
                    ShowChoice(x, y - direction);
                    prevCoords = new Point(x, y);
                    return new Point((x) * 55, (y - direction) * 55);
                }
                if (x > 1 + direction && Map[y - 1, x - direction - 1] != 0 && Map[y - 1, x - direction - 1] != 3 && CheckPrevLoc(new Point((x - direction), (y))))
                {
                    ShowChoice(x - direction, y);
                    prevCoords = new Point(x, y);
                    return new Point((x - direction) * 55, (y) * 55);
                }
            }
            prevCoords = curCoords;
            player.PlayerPosition = curCoords;//test
            return prevCoords;
        }

        private int DecrementRoll()
        {
            int result = 1;
            roll--;

            labelMovesBar.Text = roll + "/" + 6;
            progressBarMoves.Value = (int)(1.0 * roll / 6 * 1.0 * 100);
            progressBarMoves.Refresh();

            if (roll == 0)
            {

                CallBattle();
                int remainingHP = (int)(1.0 * player.Hero.Health / player.Hero.MaxHP * 100.0);
                progressBarHP.Value = remainingHP > 0 ? remainingHP : 0;
                progressBarHP.Refresh();
               

                labelMove.Text = null;
                bMove.Text = "Roll";

                UpdateInfo();

                result = 0;
                
            }
            UpdateInfo();
            //System.Threading.Thread.Sleep(1000);
            //EventArgs e = new EventArgs();
           // BMove_Click(this, e);

            return result;
        }

        //private int rolled = 0;

        private void BMove_Click(object sender, EventArgs e)
        {
          //  while (roll >= 0)
            //{

                int pictureX = player.PlayerPosition.X;
                int pictureY = player.PlayerPosition.Y;

                if (bMove.Text == "Roll")
                {
                    roll = RollADice.Roll(6);
                    //rolled = roll;
                    labelMove.Text = String.Format("You've rolled {0}", roll.ToString());
                    bMove.Text = "Move";
                }
                else if (bMove.Text == "Move")
                {

                    if (DecrementRoll() == 0)
                    {
                        return;
                    }

                    labelMove.Text = String.Format("You have {0} more moves", roll.ToString());
                    marketButton.Visible = false;
                    questButton.Visible = false;
                    PlayerPicture.Location = CheckMovement(pictureX / 55, pictureY / 55, this.player.Direction);
                    player.PlayerPosition = PlayerPicture.Location;//tied to Save function - change it, change this too (SR)
                    if (Map[(PlayerPicture.Location.Y - 1) / 55, (PlayerPicture.Location.X - 1) / 55] == 4)
                    {
                        marketButton.Visible = true;
                        questButton.Visible = true;
                    }

                    first = true;
                }

                //SaveAndLoad.Save(player);//maybe we should change the Save method place


                /*
                int pictureX = PlayerPicture.Location.X;
                int pictureY = PlayerPicture.Location.Y;

                if (button7.Text == "Roll")
                {
                    roll = RollADice.Roll(6);
                    //button7.Visible = false;
                    labelMove.Text = String.Format("You've rolled {0}", roll.ToString());
                    button7.Text = "Move";
                } else if (button7.Text == "Move")
                {
                    roll--;
                    if (roll == 0)
                    {
                        labelMove.Text = null;
                        button7.Text = "Roll";
                    }
                    labelMove.Text = String.Format("You have {0} more moves", roll.ToString());

                   PlayerPicture.Location = CheckMovement(pictureX / 55, pictureY / 55, direction);                
                }
                 * */

                System.Threading.Thread.Sleep(1000);
            }
        
        private void CallBattle()
        {

            if (RollADice.Roll(10) < 6)
            {
                DialogResult d = MessageBox.Show("You've been attacked by a group of evil monsters!  ", "Prepare for battle!", MessageBoxButtons.OK);
                
                int level = 1;
                List<Monster> monsters = FileManager.ReadMonsterList(level);

                List<Monster> monstersTeam = new List<Monster>();

                int numberOfMonsters = (player.Army.Count + 1);

                for (int i = 0; i < numberOfMonsters; i++)
                {
                    int chooseMe = RollADice.Roll(monsters.Count) - 1;

                    if (chooseMe < 0) chooseMe = 0;
                    Console.WriteLine(chooseMe + "  " + monsters.Count);
                    monstersTeam.Add(monsters[chooseMe]);
                    monsters.RemoveAt(chooseMe);
                }

                FormBattle b = new FormBattle(player, monstersTeam);
                b.Show();
}
        }

        private void FormAdventure_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DecrementRoll();

            player.Hero.Heal();
            foreach (var h in player.Army)
            {
                h.Heal();
            }

            DialogResult d = MessageBox.Show("You had some good wine, bread,  rested well and regained some of your strength! ", "Rest is best!", MessageBoxButtons.OK);
        }

        private void bFight_Click(object sender, EventArgs e)
        {
            int level = 1;
            List<Monster> monsters = FileManager.ReadMonsterList(level);

            List<Monster> monstersTeam = new List<Monster>();

            int numberOfMonsters = RollADice.Roll((player.Army.Count + 1) * 3);

            for (int i = 0; i < numberOfMonsters; i++)
            {
                int chooseMe = RollADice.Roll(monsters.Count) - 1;

                if (chooseMe < 0) chooseMe = 0;
                Console.WriteLine(chooseMe + "  " + monsters.Count);
                monstersTeam.Add(monsters[chooseMe]);
                monsters.RemoveAt(chooseMe);
            }

            FormBattle b = new FormBattle(player, monstersTeam);
            b.Show();
        }

        private void PlayerPicture_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        //Antoan
        private void marketButton_Click(object sender, EventArgs e)
        {
            List<Item> items = new List<Item>();
            items = FileManager.ReadItemList();
            FormMarket buyItemWindow = new FormMarket(player, items);
            buyItemWindow.ShowDialog();
        }
        //Antoan
        private void refreshStats_Click(object sender, EventArgs e)
        {
            InitControl();
        }

        private void questButton_Click_1(object sender, EventArgs e)
        {
            List<string> dialogs = new List<string>();
            dialogs = FileManager.ReadDialogList();
            FormQuest questWindow = new FormQuest(dialogs);
            questWindow.ShowDialog();
        }

        private void progressBarHP_Click(object sender, EventArgs e)
        {

        }

        private void progressBarMoves_Click(object sender, EventArgs e)
        {

        }
    }
}
