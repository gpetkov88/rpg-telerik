﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace Interface
{
    public class Battle
    {
        int round = 1;
        int turn = 1;
        Player player;
        List<Character> team1;
        List<Character> team2;
        bool end = false;

        public Battle(Player player, List<Character> team1, List<Character> team2)
        {
            this.player = player;
            this.team1 = team1;
            this.team2 = team2;

            round = 1;
            Random chance = new Random();
            turn = chance.Next(1, 3);

        }

        int pos1 = 0;
        int pos2 = 0;
        string team1_name;
        string team2_name;

       
        public void Run(RichTextBox battleOutput)
        {
            RichTextBox log = battleOutput;

            log.ForeColor = Color.White;
         
            log.AppendText(String.Format("                      --=== Battle Mode ===--"));
            log.AppendText(Environment.NewLine);

            Random chance = new Random();
            int enemyPos = 0;

            List<Character> team_1 = new List<Character>();
            List<Character> team_2 = new List<Character>();

            PopulateTeams(team_1, team_2, log);

            log.ForeColor = Color.Cyan;

            log.AppendText (String.Format(String.Format("Starting a new battle: *{0}* VS *{1}*! ", team1_name, team2_name)));
            //Console.ReadLine();

            log.AppendText(Environment.NewLine); 

            int myHero = ChooseAHero(log);

            bool print = true;

            while (!end)
            {
                if (print)
                {
                    log.ForeColor = Color.White;
                    log.AppendText (String.Format("---"));
                    log.AppendText (String.Format("---> Round {0}... ", round++));
                }
                if (turn == 1)
                {

                    log.ForeColor = Color.Green;
                    if (pos1 < team1.Count)
                    {
                        int heroPos = myHero;
                        if (heroPos == pos1)
                        {
                            print = true;
                            enemyPos = CharacterControl(team1[heroPos], team2, true, log);
                        }
                        else
                        {
                            // Hits a random enemy!
                            print = true;
                            enemyPos = chance.Next(team2.Count);
                            team1[pos1].Hit(team2[enemyPos]);
                            pos1++;
                            turn = 2;

                        }

                        if (team2[enemyPos].Status == "D")
                        {
                            team2.RemoveAt(enemyPos);
                            if (team2.Count <= 0)
                            {
                                log.ForeColor = Color.Green;
                                log.AppendText (String.Format("The battle is over! *{0}* won! ", team1_name));
                                end = true;
                                //Console.ReadLine();
                            }
                        }
                    }
                    else
                    {
                        pos1 = 0;
                        //round--;
                        print = false;
                    }
                }

                else if (turn == 2)
                {
                    log.ForeColor = Color.Yellow;
                    if (pos2 < team2.Count)
                    {
                        int heroPos = myHero - team2offset;
                        if (heroPos == pos2)
                        {
                            print = true;
                            enemyPos = CharacterControl(team2[heroPos], team1, false, log);
                        }
                        else
                        {

                            // Hits a random enemy!
                            print = true;
                            enemyPos = chance.Next(team1.Count);
                            team2[pos2].Hit(team1[enemyPos]);
                            pos2++;
                            turn = 1;

                        }

                        if (team1[enemyPos].Status == "D")
                        {
                            team1.RemoveAt(enemyPos);
                            if (team1.Count <= 0)
                            {
                                log.ForeColor = Color.Yellow;
                                log.AppendText (String.Format("The battle is over! *{0}* won! ", team2_name));
                                end = true;
                                //Console.ReadLine();
                            }
                        }

                    }
                    else
                    {
                        pos2 = 0;
                        //round--;
                        print = false;
                    }
                }
            }

            // END
        }

        private int CharacterControl(Character character, List<Character> EnemyTeam, bool isFirst, RichTextBox log)
        {

            log.AppendText(String.Format("It's *{0}'s* turn! ", character.Name));
            log.AppendText(String.Format("-----------------------"));
            log.AppendText(String.Format("*{0}* now has: {1} HP -- {2} Attack -- {3} Defense! ", character.Name, character.Health, character.Attack, character.Defense));
            log.AppendText(String.Format("-----------------------"));
            bool selected = false;
            int choise = 0;
            int targChoise = 0;

            while (!selected)
            {
                log.AppendText (String.Format("*{0}*: Command me, my lord! ", character.Name));
                log.AppendText(Environment.NewLine); 
                log.AppendText (String.Format("1. Hit! "));
                log.AppendText (String.Format("2. Charge! Step ahead! "));
                log.AppendText (String.Format("3. Withdraw! Step back! "));
                log.AppendText (String.Format("4. Heal your wounds! "));
                Console.Write("-> ");

                bool parsed = int.TryParse(Console.ReadLine(), out choise);

                if (parsed)
                    if (choise >= 1 && choise <= 4)
                    {
                        selected = true;
                        switch (choise)
                        {
                            case 1:
                                bool targPick = false;

                                while (!targPick)
                                {
                                    log.AppendText (String.Format("Pick a target! "));
                                    for (int i = 0; i < EnemyTeam.Count; i++)
                                    {
                                        log.AppendText (String.Format("{0}. {1}.", i + 1, EnemyTeam[i].Name));
                                    }
                                    Console.Write("-> ");

                                    bool targPars = int.TryParse(Console.ReadLine(), out targChoise);
                                    if (targPars)
                                        if (targChoise >= 1 && targChoise <= EnemyTeam.Count)
                                        {
                                            targPick = true;
                                            targChoise--;
                                            character.Hit(EnemyTeam[targChoise]);
                                            if (isFirst)
                                            {
                                                pos1++;
                                                turn = 2;
                                            }
                                            else
                                            {
                                                pos2++;
                                                turn = 1;
                                            }
                                        }
                                }

                                break;
                            case 2:
                                character.Charge();

                                if (isFirst)
                                {
                                    pos1++;
                                    turn = 2;
                                }
                                else
                                {
                                    pos2++;
                                    turn = 1;
                                }
                                break;
                            case 3:
                                character.Withdraw();

                                if (isFirst)
                                {
                                    pos1++;
                                    turn = 2;
                                }
                                else
                                {
                                    pos2++;
                                    turn = 1;
                                }
                                break;

                            case 4:
                                character.Heal();

                                if (isFirst)
                                {
                                    pos1++;
                                    turn = 2;
                                }
                                else
                                {
                                    pos2++;
                                    turn = 1;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
                        log.AppendText (String.Format("Read the menu carefully, please... "));
                    }

            }

            return targChoise;
        }

        private void PopulateTeams(List<Character> team_1, List<Character> team_2, RichTextBox log)
        {
            // Populate both teams with players
            int memberCount;

            memberCount = 0;
            while (memberCount < team1.Count)
            {
                team_1.Add(team1[memberCount++]);

                Character c1 = team_1[team_1.Count - 1];
                log.ForeColor = Color.Green;
                charPrint(c1, log);
            }
            memberCount = 0;
            while (memberCount < team2.Count)
            {
                team_2.Add(team2[memberCount++]);

                Character c2 = team_2[team_2.Count - 1];
                log.ForeColor = Color.Yellow;
                charPrint(c2, log);
            }

            for (int i = 0; i < team1.Count; i++)
            {
                if (i == team1.Count - 1)
                {
                    team1_name += team1[i].Name;
                }
                else if (i == team1.Count - 2)
                {
                    team1_name += team1[i].Name + " and ";
                }
                else
                {
                    team1_name += team1[i].Name + ", ";
                }
            }

            for (int i = 0; i < team2.Count; i++)
            {
                if (i == team2.Count - 1)
                {
                    team2_name += team2[i].Name;
                }
                else if (i == team1.Count - 2)
                {
                    team2_name += team2[i].Name + " and ";
                }
                else
                {
                    team2_name += team2[i].Name + ", ";
                }
            }
        }

        int team2offset = 100;

        private int ChooseAHero(RichTextBox log)
        {
            bool selected = false;
            int choise = 0;
            int count = 1;

            while (!selected)
            {
                count = 1;
                log.ForeColor = Color.White;
                log.AppendText (String.Format("-> Choose a hero! "));
                log.ForeColor = Color.Green;
                for (int i = 0; i < team1.Count; i++)
                {
                    log.AppendText (String.Format("{0}. {1}. ", count++, team1[i].Name));

                }
                log.ForeColor = Color.White;
                log.AppendText (String.Format("-----------------------"));
                log.ForeColor = Color.Yellow;
                for (int i = 0; i < team2.Count; i++)
                {
                    log.AppendText (String.Format("{0}. {1}. ", count++, team2[i].Name));

                }
                log.ForeColor = Color.White;
                Console.Write("-> ");

                try
                {
                    choise = int.Parse(Console.ReadLine());
                }
                catch
                {
                    log.AppendText (String.Format("Oopsy, try again? "));
                }

                if (choise >= 1 && choise <= team1.Count + team2.Count)
                {
                    selected = true;
                    log.AppendText(Environment.NewLine); 

                    if (choise <= team1.Count)
                    {
                        int index = choise - 1;
                        team1[index].Health += 10;
                        log.AppendText (String.Format("*{0}* suddenly starts feeling as \"The Chosen One\"! {0}'s health increases by 10! ", team1[index].Name));
                        return index;
                    }
                    else
                    {
                        int index = choise - team1.Count - 1;
                        team2[index].Health += 10;
                        log.AppendText (String.Format("*{0}* suddenly starts feeling as \"The Chosen One\"! {0}'s health increases by 10! ", team2[index].Name));
                        return index + team2offset;
                    }


                    ////Console.ReadLine();
                }
                else
                {
                    log.AppendText (String.Format("Just pick a number, it's not too hard... "));
                    log.AppendText(Environment.NewLine); 
                }
            }

            return 0;
        }

        private void charPrint(Character c1, RichTextBox log)
        {
            log.AppendText (String.Format("***********************************************************************"));
            log.AppendText (String.Format("* {0,-7}* |-- HP: {1,3} |-- ATTACK:  {2,3} |-- DEDENSE: {3,3} |-- RANK: {4,3}*", c1.Name, c1.Health, c1.Attack, c1.Defense, c1.Rank));
            log.AppendText (String.Format("***********************************************************************"));
            log.AppendText(Environment.NewLine); 
        }
    }
}
