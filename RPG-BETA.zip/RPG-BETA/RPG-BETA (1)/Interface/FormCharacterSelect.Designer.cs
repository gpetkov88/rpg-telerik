﻿namespace Interface
{
    partial class FormCharacterSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picArcher = new System.Windows.Forms.PictureBox();
            this.checkMage = new System.Windows.Forms.CheckBox();
            this.checkKnight = new System.Windows.Forms.CheckBox();
            this.checkArcher = new System.Windows.Forms.CheckBox();
            this.picMage = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.picKnight = new System.Windows.Forms.PictureBox();
            this.lblWarning = new System.Windows.Forms.Label();
            this.bReady = new System.Windows.Forms.Button();
            this.bBack = new System.Windows.Forms.Button();
            this.picAmazon = new System.Windows.Forms.PictureBox();
            this.checkAmazon = new System.Windows.Forms.CheckBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picArcher)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKnight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAmazon)).BeginInit();
            this.SuspendLayout();
            // 
            // picArcher
            // 
            this.picArcher.BackColor = System.Drawing.Color.Transparent;
            this.picArcher.BackgroundImage = global::Interface.Properties.Resources.Archer;
            this.picArcher.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picArcher.Location = new System.Drawing.Point(714, 269);
            this.picArcher.Name = "picArcher";
            this.picArcher.Size = new System.Drawing.Size(80, 137);
            this.picArcher.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picArcher.TabIndex = 2;
            this.picArcher.TabStop = false;
            this.picArcher.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // checkMage
            // 
            this.checkMage.AutoSize = true;
            this.checkMage.BackColor = System.Drawing.Color.Transparent;
            this.checkMage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkMage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkMage.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkMage.Location = new System.Drawing.Point(297, 221);
            this.checkMage.Name = "checkMage";
            this.checkMage.Size = new System.Drawing.Size(97, 24);
            this.checkMage.TabIndex = 3;
            this.checkMage.Text = "Sorcerer";
            this.checkMage.UseVisualStyleBackColor = false;
            this.checkMage.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkKnight
            // 
            this.checkKnight.AutoSize = true;
            this.checkKnight.BackColor = System.Drawing.Color.Transparent;
            this.checkKnight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkKnight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkKnight.ForeColor = System.Drawing.SystemColors.Highlight;
            this.checkKnight.Location = new System.Drawing.Point(511, 221);
            this.checkKnight.Name = "checkKnight";
            this.checkKnight.Size = new System.Drawing.Size(79, 24);
            this.checkKnight.TabIndex = 4;
            this.checkKnight.Text = "Knight";
            this.checkKnight.UseVisualStyleBackColor = false;
            this.checkKnight.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkArcher
            // 
            this.checkArcher.AutoSize = true;
            this.checkArcher.BackColor = System.Drawing.Color.Transparent;
            this.checkArcher.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkArcher.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkArcher.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkArcher.Location = new System.Drawing.Point(713, 221);
            this.checkArcher.Name = "checkArcher";
            this.checkArcher.Size = new System.Drawing.Size(81, 24);
            this.checkArcher.TabIndex = 5;
            this.checkArcher.Text = "Archer";
            this.checkArcher.UseVisualStyleBackColor = false;
            this.checkArcher.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // picMage
            // 
            this.picMage.BackColor = System.Drawing.Color.Transparent;
            this.picMage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picMage.Image = global::Interface.Properties.Resources.Sorcerer;
            this.picMage.Location = new System.Drawing.Point(297, 269);
            this.picMage.Name = "picMage";
            this.picMage.Size = new System.Drawing.Size(80, 134);
            this.picMage.TabIndex = 6;
            this.picMage.TabStop = false;
            this.picMage.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(-23, -45);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // picKnight
            // 
            this.picKnight.BackColor = System.Drawing.Color.Transparent;
            this.picKnight.BackgroundImage = global::Interface.Properties.Resources.Knight_t;
            this.picKnight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picKnight.Location = new System.Drawing.Point(514, 269);
            this.picKnight.Name = "picKnight";
            this.picKnight.Size = new System.Drawing.Size(76, 137);
            this.picKnight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picKnight.TabIndex = 8;
            this.picKnight.TabStop = false;
            this.picKnight.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // lblWarning
            // 
            this.lblWarning.AutoSize = true;
            this.lblWarning.BackColor = System.Drawing.Color.Transparent;
            this.lblWarning.Font = new System.Drawing.Font("Arial", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWarning.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblWarning.Location = new System.Drawing.Point(390, 120);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(483, 36);
            this.lblWarning.TabIndex = 9;
            this.lblWarning.Text = "Choose your character wisely!";
            // 
            // bReady
            // 
            this.bReady.BackColor = System.Drawing.Color.Transparent;
            this.bReady.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bReady.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bReady.Location = new System.Drawing.Point(548, 481);
            this.bReady.Name = "bReady";
            this.bReady.Size = new System.Drawing.Size(95, 47);
            this.bReady.TabIndex = 10;
            this.bReady.Text = "Ready!";
            this.bReady.UseVisualStyleBackColor = false;
            this.bReady.Click += new System.EventHandler(this.button1_Click);
            // 
            // bBack
            // 
            this.bBack.BackColor = System.Drawing.Color.Transparent;
            this.bBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bBack.Location = new System.Drawing.Point(655, 481);
            this.bBack.Name = "bBack";
            this.bBack.Size = new System.Drawing.Size(93, 47);
            this.bBack.TabIndex = 11;
            this.bBack.Text = "Back";
            this.bBack.UseVisualStyleBackColor = false;
            this.bBack.Click += new System.EventHandler(this.button2_Click);
            // 
            // picAmazon
            // 
            this.picAmazon.BackColor = System.Drawing.Color.Transparent;
            this.picAmazon.BackgroundImage = global::Interface.Properties.Resources.Amazon_t;
            this.picAmazon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picAmazon.Location = new System.Drawing.Point(899, 266);
            this.picAmazon.Name = "picAmazon";
            this.picAmazon.Size = new System.Drawing.Size(80, 137);
            this.picAmazon.TabIndex = 13;
            this.picAmazon.TabStop = false;
            this.picAmazon.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // checkAmazon
            // 
            this.checkAmazon.AutoSize = true;
            this.checkAmazon.BackColor = System.Drawing.Color.Transparent;
            this.checkAmazon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkAmazon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkAmazon.ForeColor = System.Drawing.Color.PeachPuff;
            this.checkAmazon.Location = new System.Drawing.Point(898, 221);
            this.checkAmazon.Name = "checkAmazon";
            this.checkAmazon.Size = new System.Drawing.Size(93, 24);
            this.checkAmazon.TabIndex = 14;
            this.checkAmazon.Text = "Amazon";
            this.checkAmazon.UseVisualStyleBackColor = false;
            this.checkAmazon.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(548, 435);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(200, 20);
            this.txtName.TabIndex = 15;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.SystemColors.Control;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblName.Location = new System.Drawing.Point(621, 412);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(55, 20);
            this.lblName.TabIndex = 16;
            this.lblName.Text = "Name:";
            this.lblName.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // FormCharacterSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(968, 470);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.checkAmazon);
            this.Controls.Add(this.picAmazon);
            this.Controls.Add(this.bBack);
            this.Controls.Add(this.bReady);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.picKnight);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.picMage);
            this.Controls.Add(this.checkArcher);
            this.Controls.Add(this.checkKnight);
            this.Controls.Add(this.checkMage);
            this.Controls.Add(this.picArcher);
            this.Name = "FormCharacterSelect";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picArcher)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKnight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAmazon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picArcher;
        private System.Windows.Forms.CheckBox checkMage;
        private System.Windows.Forms.CheckBox checkKnight;
        private System.Windows.Forms.CheckBox checkArcher;
        private System.Windows.Forms.PictureBox picMage;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox picKnight;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.Button bReady;
        private System.Windows.Forms.Button bBack;
        private System.Windows.Forms.PictureBox picAmazon;
        private System.Windows.Forms.CheckBox checkAmazon;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
    }
}