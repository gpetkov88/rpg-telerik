﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Interface
{
    class FileManager
    {
        static List<string> log = new List<string>();

        static string DefaultTextFileDir = "Files\\";

        // LIST OF Filenames:
        static string fileHeroes = DefaultTextFileDir + "Heroes.txt";
        static string fileMonsters1 = DefaultTextFileDir + "Monsters1.txt";
        static string fileMonsters2 = DefaultTextFileDir + "Monsters2.txt";
        static string fileMonsters3 = DefaultTextFileDir + "Monsters3.txt";

        // ----------------

        // READ CHARACTERS FROM A FILE:
        public static List<Character> ReadCharacterList()
        {
            List<Character> newChars = new List<Character>();
            Console.WriteLine("Reading: {0}" + fileHeroes);
            try
            {
                StreamReader reader = new StreamReader(fileHeroes);
                
                using (reader)
                {
                    while (!reader.EndOfStream)
                    {
                        try
                        {
                            string[] record = reader.ReadLine().Split(' ');

                            if (record[0] == "+")
                            {
                                string name = record[1];
                                int hp = int.Parse(record[2]);
                                int at = int.Parse(record[3]);
                                int def = int.Parse(record[4]);
                                Character newChar = new Character(name, hp, at, def);


                                newChars.Add(newChar);

                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            log.Add("The input file is corrupted! Please verify the exact record's format! ");
                        }
                    }
                }
                return newChars;
            }
            catch
            {

                log.Add(String.Format("File {0} not found! ", fileHeroes));
                return newChars;
            }
            
        }

        // READ MONSTERS FROM A FILE:
        public static List<Monster> ReadMonsterList(int level)
        {
            string filename = "";
            if (level == 1) filename = fileMonsters1;
            if (level == 2) filename = fileMonsters2;
            if (level == 3) filename = fileMonsters3;

            List<Monster> newMonsters = new List<Monster>();
            Console.WriteLine("Reading: {0}" + filename);
            try
            {
                StreamReader reader = new StreamReader(filename);

                using (reader)
                {
                    while (!reader.EndOfStream)
                    {
                        try
                        {
                            string[] record = reader.ReadLine().Split(' ');
                            Console.WriteLine(record.Length);
                            Console.WriteLine(record[1]);
                            if (record[0] == "+")
                            {
                                string name = record[1];
                                int hp = int.Parse(record[2]);
                                int at = int.Parse(record[3]);
                                int def = int.Parse(record[4]);
                                int monsterLevel = int.Parse(record[5]);
                                Monster newMonster = new Monster(name, hp, at, def, monsterLevel);
                                //Console.WriteLine("Monster {0} {1} {2} {3} {4} {5} written! ", newMonster.Name, newMonster.Health, newMonster.Attack, newMonster.Defense, newMonster.Level);

                                newMonsters.Add(newMonster);

                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            log.Add("The input file is corrupted! Please verify the exact record's format! ");
                        }
                    }
                }
                return newMonsters;
            }
            catch
            {

                log.Add(String.Format("File {0} not found! ", filename));
                return newMonsters;
            }

        }
    }
}
   
