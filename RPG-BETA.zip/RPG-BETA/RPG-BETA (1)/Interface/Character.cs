﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    public class Character : Creature, IDefenseBonus, IAttackBonus, ILifeBonus, IPayWithGold
    {
        string name = "Adventurer";
        int hp = 100;
        int attack = 30;
        int defense = 30;
        string status = "N";
        int rank = 0;

        public int Gold { get; set; }

        public List<Item> Items = new List<Item>();

        public Character(string name_, int hp_, int attack_, int defense_)
            : base(name_, hp_, attack_, defense_)
        {
            name = name_;
            hp = hp_;
            attack = attack_;
            defense = defense_;
            status = "A";
            Gold = 10;
        }

        public void IncreaseAttack(int attack)
        {
            this.Attack += attack;
        }
        public void IncreaseDefense(int defense)
        {
            this.Defense += defense;
        }
        public void IncreaseLife(int life)
        {
            this.MaxHP += life;
        }
        public void GoldIncreaseOrDecrease(int amount)
        {
            this.Gold += amount;
        }

        public List<string> Hit(Character enemy)
        {
            //log.Clear();
            log.Add(String.Format("*{0}* attacks *{1}* with incredible anger! ", Name, enemy.Name));

            int damage = Attack + RollADice.Roll(10);
            int[] codes = enemy.getHit(damage);

            // Copy target log
            foreach (string text in enemy.log)
            {
                log.Add(Environment.NewLine);
                log.Add(text);
                
            }
            log.Add(Environment.NewLine);

            // Clear the target log
            enemy.log.Clear();

            if (codes[0] == 1)
            {

                if (RollADice.Roll(10) <= 1)
                {
                    log.Add(String.Format("Seeing the devastating power of this blow *{0}* decides to act more carefully from now on! ", Name));
                    int critBonus = Math.Abs(codes[1]) / 3;
                    Defense += critBonus;
                    log.Add(String.Format("*{0}'s* defense increases by {1} to {2}! ", Name, critBonus, Defense));
                }

                if (RollADice.Roll(10) <= 1)
                {
                    log.Add(String.Format("*{0}* feels a lot more confident with delivering deadly strikes now! ", Name));
                    int critBonus = Math.Abs(codes[1]) / 3;
                    Attack += critBonus;
                    log.Add(String.Format("*{0}'s* attack increases by {1} to {2}! ", Name, critBonus, Attack));
                }
            }



            return log;
        }

        public int[] getHit(int attack)
        {
            int[] codes = new int[2];

            int chance = RollADice.Roll(10);
            int damage;

            bool odds = attack > Defense + chance;
            if (odds)
            {
                damage = attack - (Defense + chance);
                if (RollADice.Roll(10) <= 1)
                {
                    log.Add(String.Format("*** CRITICAL STRIKE ***  "));
                    
                    codes[0] = 1;
                    codes[1] = damage;
                    this.Attack = this.Attack - damage / 2;
                    this.Defense = this.Defense - damage / 2;
                    damage = damage * 2;

                    Health = Health - damage;
                    log.Add(String.Format("That was a devastating blow!!! {0} lost {1} health and had a severe skill desintegration! ", Name, damage));
                    
                    log.Add(String.Format("{0} now has {1} health! ", Name, Health));
                    log.Add(String.Format("{0}'s attack drops down to {1}! ", Name, Attack));
                    log.Add(String.Format("{0}'s defense drops down to {1}! ", Name, Defense));
                    

                }
                else
                {
                    Health = Health - damage;
                    log.Add(String.Format("Ouch.. that hurt! {0} lost {1} health! ", Name, damage));
                    log.Add(String.Format("{0} now has {1} health! ", Name, Health));
                }
            }
            else
            {
                if (RollADice.Roll(5) <= 1)
                {
                    int counter = Math.Abs(attack - (Defense + chance)) / 3;
                    log.Add(String.Format("{0} dodges the blow swiftly and counterattacks! His attack increases by {1}! ", Name, ++counter));
                    Attack = Attack + counter;
                }
                else
                {
                    log.Add(String.Format("Wow! That went so close but just *missed* the target! "));
                }
            }

            if (Health <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                
                log.Add(String.Format("                           -xXx- "));
                log.Add(String.Format("-xXx- That was a crucial blow! *{0}* is now dead! -xXx-", Name));
                log.Add(String.Format("                           -xXx- "));
                Status = "D";
                IsAlive = false;
                
            }


            return codes;
        }



        internal List<String> Charge()
        {
            log.Clear();
            int oldAttack = Attack;
            int oldDefense = Defense;

            int change = RollADice.Roll(5);
            Attack += change;
            Defense -= change;
            log.Add(String.Format("*{0}* charges bravely at his foes! ", Name));
            log.Add(String.Format("*{0}'s* Attack is now {1}! ({2})", Name, Attack, Attack - oldAttack));
            log.Add(String.Format("*{0}'s Defense is now {1}! ({2})", Name, Defense, Defense - oldDefense));

            return log;
        }

        internal List<String> Withdraw()
        {
            log.Clear();
            int oldAttack = Attack;
            int oldDefense = Defense;


            int change = RollADice.Roll(5);
            Attack -= change;
            Defense += change;
            log.Add(String.Format("*{0}* steps back and takes a defensive stand! ", Name));
            log.Add(String.Format("*{0}'s* Attack is now {1}! ", Name, Attack, Attack - oldAttack));
            log.Add(String.Format("*{0}'s Defense is now {1}! ", Name, Defense, Defense - oldDefense));
            return log;
        }

        internal List<String> Heal()
        {
            log.Clear();

            int restore = RollADice.Roll(10);
            Health += restore;
            if (Health > MaxHP)
            {
                Health = MaxHP;
                log.Add(String.Format("*{0}* is already at full health: {1}!", Name, Health));
            }
            else
            {
                log.Add(String.Format("*{0}* quickly bandages his wounds restoring {1} health! ", Name, restore));
                log.Add(String.Format("*{0}'s* health is now {1}! ", Name, Health));
            }
            return log;
        }

    }

}
