﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Interface
{
    class FileManager
    {
        static List<string> log = new List<string>();

        static string DefaultTextFileDir = "Files\\";

        // LIST OF Filenames:
        static string fileHeroes = DefaultTextFileDir + "Heroes.txt";
        static string fileMonsters1 = DefaultTextFileDir + "Monsters1.txt";
        static string fileMonsters2 = DefaultTextFileDir + "Monsters2.txt";
        static string fileMonsters3 = DefaultTextFileDir + "Monsters3.txt";
        static string fileItems = DefaultTextFileDir + "Items.txt";
        static string fileDialogs = DefaultTextFileDir + "Dialogs.txt";
        // ----------------

        // READ CHARACTERS FROM A FILE:
        public static List<Character> ReadCharacterList()
        {
            List<Character> newChars = new List<Character>();
            Console.WriteLine("Reading: {0}" + fileHeroes);
            try
            {
                StreamReader reader = new StreamReader(fileHeroes);

                using (reader)
                {
                    while (!reader.EndOfStream)
                    {
                        try
                        {
                            string[] record = reader.ReadLine().Split(' ');

                            if (record[0] == "+")
                            {
                                string name = record[1];
                                int hp = int.Parse(record[2]);
                                int at = int.Parse(record[3]);
                                int def = int.Parse(record[4]);
                                Character newChar = new Character(name, hp, at, def);


                                newChars.Add(newChar);

                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            log.Add("The input file is corrupted! Please verify the exact record's format! ");
                        }
                    }
                }
                return newChars;
            }
            catch
            {

                log.Add(String.Format("File {0} not found! ", fileHeroes));
                return newChars;
            }

        }
        //READ ITEMS From File
        public static List<Item> ReadItemList()
        {
            List<Item> newItems = new List<Item>();
            Console.WriteLine("Reading: {0}" + fileItems);
            try
            {
                StreamReader reader = new StreamReader(fileItems);

                using (reader)
                {
                    while (!reader.EndOfStream)
                    {
                        try
                        {
                            string[] record = reader.ReadLine().Split(' ');

                            if (record[0] == "+")
                            {
                                string name = record[1];
                                int buyCost = int.Parse(record[2]);
                                int sellCost = int.Parse(record[3]);
                                int attBonus = int.Parse(record[4]);
                                int defBonus = int.Parse(record[5]);
                                int lifeBonus = int.Parse(record[6]);
                                int magicBonus = int.Parse(record[7]);
                                Item newItem = new Item(name, buyCost, sellCost, attBonus, defBonus, lifeBonus, magicBonus);
                                newItems.Add(newItem);
                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            log.Add("The input file is corrupted! Please verify the exact record's format! ");
                        }
                    }
                }
                return newItems;
            }
            catch
            {

                log.Add(String.Format("File {0} not found! ", fileItems));
                return newItems;
            }
        }
        // Read dialogs (quests) from file
        public static List<string> ReadDialogList()
        {
            List<string> newDialogs = new List<string>();
            Console.WriteLine("Reading: {0}" + fileDialogs);
            try
            {
                StreamReader reader = new StreamReader(fileDialogs);

                using (reader)
                {
                    while (!reader.EndOfStream)
                    {
                        StringBuilder scenario = new StringBuilder();
                        string line = reader.ReadLine();
                        while (true)
                        {
                            if (line == "---") //dialog separateor, also after last dialog put this, otherwies endelss while loop!
                            {
                                break;
                            }
                            if (line.StartsWith("//") == false) //lines in txt wicht starts with // will not be read!
                            {
                                scenario.Append(line);
                                scenario.Append(Environment.NewLine);
                            }
                            line = reader.ReadLine();
                        }
                        newDialogs.Add(scenario.ToString());
                    }
                }
                return newDialogs;
            }
            catch
            {
                log.Add(String.Format("File {0} not found! ", fileDialogs));
                return newDialogs;
            }
        }
        // READ MONSTERS FROM A FILE:
        public static List<Monster> ReadMonsterList(int level)
        {
            string filename = "";
            if (level == 1) filename = fileMonsters1;
            if (level == 2) filename = fileMonsters2;
            if (level == 3) filename = fileMonsters3;

            List<Monster> newMonsters = new List<Monster>();
            Console.WriteLine("Reading: {0}", filename);
            //Console.WriteLine("Debug1");
            try
            {
                StreamReader reader = new StreamReader(filename);

                using (reader)
                {
                    while (!reader.EndOfStream)
                    {
                        try
                        {
                            //Console.WriteLine("Debug2");
                            string[] record = reader.ReadLine().Split(' ');
                            //Console.WriteLine(record.Length);

                            if (record[0] == "+")
                            {
                                //Console.WriteLine("Debug3");
                                string name = record[1];
                                int hp = int.Parse(record[2]);
                                int at = int.Parse(record[3]);
                                int def = int.Parse(record[4]);
                                int monsterLevel = int.Parse(record[5]);
                                Monster newMonster = new Monster(name, hp, at, def, monsterLevel);

                                Console.WriteLine("Debug4");
                               // Console.WriteLine("Monster {0} {1} {2} {3} {4} {5} read! ", newMonster.Name, //newMonster.Health,newMonster.Attack, newMonster.Defense, newMonster.Level);

                                newMonsters.Add(newMonster);

                            }
                        }
                        catch (IndexOutOfRangeException)
                        {
                            log.Add("The input file is corrupted! Please verify the exact record's format! ");
                        }
                    }
                }
                Console.WriteLine("-> " + newMonsters.Count);
                return newMonsters;
            }
            catch
            {

                log.Add(String.Format("File {0} not found! ", filename));
                return newMonsters;
            }

        }
    }
}

