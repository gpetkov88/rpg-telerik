﻿using System;
using System.Linq;

namespace Interface
{
    public static class RollADice
    {
        static Random rand = new Random();

        public static int Roll(int Range)
        {
            return rand.Next(1, Range + 1);
        }
    }
}
