﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.IO;
using WMPLib;

namespace Interface
{
    public partial class FormMainMenu : Form
    {
        private WindowsMediaPlayer wplayer; 


        public FormMainMenu()
        {
            InitializeComponent();
            try
            {
                wplayer = new WMPLib.WindowsMediaPlayer();
                wplayer.URL = @"Sounds\Talpa - Away.mp3";
                wplayer.settings.setMode("loop", true);
            }
            catch 
            {
                FileNotFoundException fnf = new FileNotFoundException();
                Console.WriteLine(fnf.ToString());
            }

            cbMusicSwitch.Checked = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bFight_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCharacterSelect f2 = new FormCharacterSelect(wplayer);
            f2.ShowDialog();
            //f2.Visible = true;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            cbMusicSwitch.BackColor = Color.DarkGray;
            if (cbMusicSwitch.Checked)
            {
                //checkBox1.Text = "Music Off";
                wplayer.controls.play();

            }
            else
            {
                //checkBox1.Text = "Music On";
                wplayer.controls.stop();

            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Player loadedPlayer = SaveAndLoad.Load();
            FormAdventure f3 = new FormAdventure(loadedPlayer);
            f3.LoadState();
        }
    }
}
