﻿namespace Interface
{
    partial class FormMarket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picSellsman = new System.Windows.Forms.PictureBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.buttonBuy = new System.Windows.Forms.Button();
            this.lblRingStats = new System.Windows.Forms.Label();
            this.checkBoxRing = new System.Windows.Forms.CheckBox();
            this.picRing = new System.Windows.Forms.PictureBox();
            this.lblShieldStats = new System.Windows.Forms.Label();
            this.checkBoxShield = new System.Windows.Forms.CheckBox();
            this.lblShieldPrice = new System.Windows.Forms.Label();
            this.picShield = new System.Windows.Forms.PictureBox();
            this.lblBreastStats = new System.Windows.Forms.Label();
            this.checkBoxBreasplate = new System.Windows.Forms.CheckBox();
            this.picBreastplate = new System.Windows.Forms.PictureBox();
            this.checkBoxSword = new System.Windows.Forms.CheckBox();
            this.lblSwordStats = new System.Windows.Forms.Label();
            this.picSword = new System.Windows.Forms.PictureBox();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.lblShieldSellingPrice = new System.Windows.Forms.Label();
            this.lblSwordSellingPrice = new System.Windows.Forms.Label();
            this.lblSwordPrice = new System.Windows.Forms.Label();
            this.lblBreastSellingPrice = new System.Windows.Forms.Label();
            this.lblBreastPrice = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picSellsman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShield)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBreastplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSword)).BeginInit();
            this.SuspendLayout();
            // 
            // picSellsman
            // 
            this.picSellsman.Image = global::Interface.Properties.Resources.artefact_dealer;
            this.picSellsman.Location = new System.Drawing.Point(327, 12);
            this.picSellsman.Name = "picSellsman";
            this.picSellsman.Size = new System.Drawing.Size(106, 63);
            this.picSellsman.TabIndex = 1;
            this.picSellsman.TabStop = false;
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(308, 78);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(163, 13);
            this.lblMessage.TabIndex = 3;
            this.lblMessage.Text = "You can buy some artefacts here";
            // 
            // buttonBuy
            // 
            this.buttonBuy.Location = new System.Drawing.Point(242, 407);
            this.buttonBuy.Name = "buttonBuy";
            this.buttonBuy.Size = new System.Drawing.Size(130, 39);
            this.buttonBuy.TabIndex = 35;
            this.buttonBuy.Text = "Buy";
            this.buttonBuy.UseVisualStyleBackColor = true;
            this.buttonBuy.Click += new System.EventHandler(this.buttonBuy_Click);
            // 
            // lblRingStats
            // 
            this.lblRingStats.AutoSize = true;
            this.lblRingStats.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblRingStats.Location = new System.Drawing.Point(464, 322);
            this.lblRingStats.Name = "lblRingStats";
            this.lblRingStats.Size = new System.Drawing.Size(208, 13);
            this.lblRingStats.TabIndex = 34;
            this.lblRingStats.Text = "+1 Attack, +1 Defense, +10 Life, +1 Magic";
            // 
            // checkBoxRing
            // 
            this.checkBoxRing.AutoSize = true;
            this.checkBoxRing.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.checkBoxRing.Location = new System.Drawing.Point(464, 302);
            this.checkBoxRing.Name = "checkBoxRing";
            this.checkBoxRing.Size = new System.Drawing.Size(91, 17);
            this.checkBoxRing.TabIndex = 33;
            this.checkBoxRing.Text = "buy ring of life";
            this.checkBoxRing.UseVisualStyleBackColor = false;
            this.checkBoxRing.CheckedChanged += new System.EventHandler(this.checkBoxRing_CheckedChanged);
            // 
            // picRing
            // 
            this.picRing.Image = global::Interface.Properties.Resources.Artifact_Ring_of_Life;
            this.picRing.Location = new System.Drawing.Point(464, 254);
            this.picRing.Name = "picRing";
            this.picRing.Size = new System.Drawing.Size(46, 44);
            this.picRing.TabIndex = 31;
            this.picRing.TabStop = false;
            // 
            // lblShieldStats
            // 
            this.lblShieldStats.AutoSize = true;
            this.lblShieldStats.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblShieldStats.Location = new System.Drawing.Point(239, 322);
            this.lblShieldStats.Name = "lblShieldStats";
            this.lblShieldStats.Size = new System.Drawing.Size(197, 13);
            this.lblShieldStats.TabIndex = 30;
            this.lblShieldStats.Text = "+8 Defence, 3 Attack, +1 Life, +1 Magic";
            // 
            // checkBoxShield
            // 
            this.checkBoxShield.AutoSize = true;
            this.checkBoxShield.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.checkBoxShield.Location = new System.Drawing.Point(239, 302);
            this.checkBoxShield.Name = "checkBoxShield";
            this.checkBoxShield.Size = new System.Drawing.Size(152, 17);
            this.checkBoxShield.TabIndex = 29;
            this.checkBoxShield.Text = "buy shield of the dammend";
            this.checkBoxShield.UseVisualStyleBackColor = false;
            this.checkBoxShield.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // lblShieldPrice
            // 
            this.lblShieldPrice.AutoSize = true;
            this.lblShieldPrice.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblShieldPrice.Location = new System.Drawing.Point(239, 339);
            this.lblShieldPrice.Name = "lblShieldPrice";
            this.lblShieldPrice.Size = new System.Drawing.Size(64, 13);
            this.lblShieldPrice.TabIndex = 28;
            this.lblShieldPrice.Text = "25 Gold buy";
            // 
            // picShield
            // 
            this.picShield.Image = global::Interface.Properties.Resources.Artifact_Shield_of_the_Damned;
            this.picShield.Location = new System.Drawing.Point(239, 254);
            this.picShield.Name = "picShield";
            this.picShield.Size = new System.Drawing.Size(46, 44);
            this.picShield.TabIndex = 27;
            this.picShield.TabStop = false;
            // 
            // lblBreastStats
            // 
            this.lblBreastStats.AutoSize = true;
            this.lblBreastStats.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblBreastStats.Location = new System.Drawing.Point(464, 202);
            this.lblBreastStats.Name = "lblBreastStats";
            this.lblBreastStats.Size = new System.Drawing.Size(208, 13);
            this.lblBreastStats.TabIndex = 26;
            this.lblBreastStats.Text = "+1 Attack, +1 Defense, +1 Life, +10 Magic";
            // 
            // checkBoxBreasplate
            // 
            this.checkBoxBreasplate.AutoSize = true;
            this.checkBoxBreasplate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.checkBoxBreasplate.Location = new System.Drawing.Point(464, 182);
            this.checkBoxBreasplate.Name = "checkBoxBreasplate";
            this.checkBoxBreasplate.Size = new System.Drawing.Size(158, 17);
            this.checkBoxBreasplate.TabIndex = 25;
            this.checkBoxBreasplate.Text = "buy breastplate of brimstone";
            this.checkBoxBreasplate.UseVisualStyleBackColor = false;
            this.checkBoxBreasplate.CheckedChanged += new System.EventHandler(this.checkBoxBreasplate_CheckedChanged);
            // 
            // picBreastplate
            // 
            this.picBreastplate.Image = global::Interface.Properties.Resources.Artifact_Breastplate_of_Brimstone;
            this.picBreastplate.Location = new System.Drawing.Point(464, 130);
            this.picBreastplate.Name = "picBreastplate";
            this.picBreastplate.Size = new System.Drawing.Size(46, 44);
            this.picBreastplate.TabIndex = 23;
            this.picBreastplate.TabStop = false;
            // 
            // checkBoxSword
            // 
            this.checkBoxSword.AutoSize = true;
            this.checkBoxSword.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.checkBoxSword.Location = new System.Drawing.Point(239, 182);
            this.checkBoxSword.Name = "checkBoxSword";
            this.checkBoxSword.Size = new System.Drawing.Size(138, 17);
            this.checkBoxSword.TabIndex = 22;
            this.checkBoxSword.Text = "buy sword of judgement";
            this.checkBoxSword.UseVisualStyleBackColor = false;
            this.checkBoxSword.CheckedChanged += new System.EventHandler(this.checkBoxSword_CheckedChanged);
            // 
            // lblSwordStats
            // 
            this.lblSwordStats.AutoSize = true;
            this.lblSwordStats.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblSwordStats.Location = new System.Drawing.Point(239, 202);
            this.lblSwordStats.Name = "lblSwordStats";
            this.lblSwordStats.Size = new System.Drawing.Size(206, 13);
            this.lblSwordStats.TabIndex = 20;
            this.lblSwordStats.Text = "+8 Attack, +3 Defence, +1 Life, +1 Magic ";
            // 
            // picSword
            // 
            this.picSword.Image = global::Interface.Properties.Resources.Sword_of_Judgement;
            this.picSword.Location = new System.Drawing.Point(237, 130);
            this.picSword.Name = "picSword";
            this.picSword.Size = new System.Drawing.Size(46, 44);
            this.picSword.TabIndex = 19;
            this.picSword.TabStop = false;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(510, 407);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(126, 39);
            this.buttonCancel.TabIndex = 36;
            this.buttonCancel.Text = "Close";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.label10_Click);
            // 
            // lblShieldSellingPrice
            // 
            this.lblShieldSellingPrice.AutoSize = true;
            this.lblShieldSellingPrice.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblShieldSellingPrice.Location = new System.Drawing.Point(310, 339);
            this.lblShieldSellingPrice.Name = "lblShieldSellingPrice";
            this.lblShieldSellingPrice.Size = new System.Drawing.Size(62, 13);
            this.lblShieldSellingPrice.TabIndex = 37;
            this.lblShieldSellingPrice.Text = "15 Gold sell";
            // 
            // lblSwordSellingPrice
            // 
            this.lblSwordSellingPrice.AutoSize = true;
            this.lblSwordSellingPrice.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblSwordSellingPrice.Location = new System.Drawing.Point(310, 220);
            this.lblSwordSellingPrice.Name = "lblSwordSellingPrice";
            this.lblSwordSellingPrice.Size = new System.Drawing.Size(62, 13);
            this.lblSwordSellingPrice.TabIndex = 39;
            this.lblSwordSellingPrice.Text = "15 Gold sell";
            // 
            // lblSwordPrice
            // 
            this.lblSwordPrice.AutoSize = true;
            this.lblSwordPrice.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblSwordPrice.Location = new System.Drawing.Point(239, 220);
            this.lblSwordPrice.Name = "lblSwordPrice";
            this.lblSwordPrice.Size = new System.Drawing.Size(64, 13);
            this.lblSwordPrice.TabIndex = 38;
            this.lblSwordPrice.Text = "25 Gold buy";
            // 
            // lblBreastSellingPrice
            // 
            this.lblBreastSellingPrice.AutoSize = true;
            this.lblBreastSellingPrice.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblBreastSellingPrice.Location = new System.Drawing.Point(535, 220);
            this.lblBreastSellingPrice.Name = "lblBreastSellingPrice";
            this.lblBreastSellingPrice.Size = new System.Drawing.Size(62, 13);
            this.lblBreastSellingPrice.TabIndex = 41;
            this.lblBreastSellingPrice.Text = "15 Gold sell";
            // 
            // lblBreastPrice
            // 
            this.lblBreastPrice.AutoSize = true;
            this.lblBreastPrice.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblBreastPrice.Location = new System.Drawing.Point(464, 220);
            this.lblBreastPrice.Name = "lblBreastPrice";
            this.lblBreastPrice.Size = new System.Drawing.Size(64, 13);
            this.lblBreastPrice.TabIndex = 40;
            this.lblBreastPrice.Text = "25 Gold buy";
            // 
            // lbl
            // 
            this.lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl.Location = new System.Drawing.Point(377, 379);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(0, 24);
            this.lbl.TabIndex = 43;
            this.lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormMarket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Interface.Properties.Resources.ch_hill1;
            this.ClientSize = new System.Drawing.Size(677, 454);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.lblBreastSellingPrice);
            this.Controls.Add(this.lblBreastPrice);
            this.Controls.Add(this.lblSwordSellingPrice);
            this.Controls.Add(this.lblSwordPrice);
            this.Controls.Add(this.lblShieldSellingPrice);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonBuy);
            this.Controls.Add(this.lblRingStats);
            this.Controls.Add(this.checkBoxRing);
            this.Controls.Add(this.picRing);
            this.Controls.Add(this.lblShieldStats);
            this.Controls.Add(this.checkBoxShield);
            this.Controls.Add(this.lblShieldPrice);
            this.Controls.Add(this.picShield);
            this.Controls.Add(this.lblBreastStats);
            this.Controls.Add(this.checkBoxBreasplate);
            this.Controls.Add(this.picBreastplate);
            this.Controls.Add(this.checkBoxSword);
            this.Controls.Add(this.lblSwordStats);
            this.Controls.Add(this.picSword);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.picSellsman);
            this.Name = "FormMarket";
            this.Text = "Marketplace";
            ((System.ComponentModel.ISupportInitialize)(this.picSellsman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picShield)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBreastplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSword)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picSellsman;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button buttonBuy;
        private System.Windows.Forms.Label lblRingStats;
        private System.Windows.Forms.CheckBox checkBoxRing;
        private System.Windows.Forms.PictureBox picRing;
        private System.Windows.Forms.Label lblShieldStats;
        private System.Windows.Forms.CheckBox checkBoxShield;
        private System.Windows.Forms.Label lblShieldPrice;
        private System.Windows.Forms.PictureBox picShield;
        private System.Windows.Forms.Label lblBreastStats;
        private System.Windows.Forms.CheckBox checkBoxBreasplate;
        private System.Windows.Forms.PictureBox picBreastplate;
        private System.Windows.Forms.CheckBox checkBoxSword;
        private System.Windows.Forms.Label lblSwordStats;
        private System.Windows.Forms.PictureBox picSword;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label lblShieldSellingPrice;
        private System.Windows.Forms.Label lblSwordSellingPrice;
        private System.Windows.Forms.Label lblSwordPrice;
        private System.Windows.Forms.Label lblBreastSellingPrice;
        private System.Windows.Forms.Label lblBreastPrice;
        private System.Windows.Forms.Label lbl;
    }
}