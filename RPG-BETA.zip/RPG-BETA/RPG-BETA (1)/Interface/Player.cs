﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;

namespace Interface
{

    public class Player
    {
        public string Name { get; set; }
        public EHeroes PlayerProffesion { get; set; }
        public int Direction { get; set; }
        public Character Hero { get; set; }
        public List<Character> Army { get; set; }

        public Point PlayerPosition { get; set; }
        public Player(string name, EHeroes playerProffesion, Character hero, List<Character> army)
        {
            this.Name = name;
            this.PlayerProffesion = playerProffesion;
            this.Direction = -1;
            this.PlayerPosition = new Point(882, 660);
            this.Hero = hero;
            this.Army = army;
        }
        public Player()
        {

        }

    }
}