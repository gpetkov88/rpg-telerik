﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;

namespace Interface
{
    public class Field
    {
        public int Code { get; set; }
        public Point Center { get; set; }

        public Field(int code, Point Center)
        {
            this.Code = code;
            this.Center = Center;
        }
    }
}
