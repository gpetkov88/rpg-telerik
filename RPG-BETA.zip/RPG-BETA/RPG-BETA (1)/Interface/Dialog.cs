﻿using System;
using System.Linq;

namespace Interface
{
   public class Dialog 
    {
        private string text;
        public string Text
        {
            get { return this.text; }
            set { this.text = value; }
        }
        public Dialog (string text)
        {
            this.Text = text;
        }
    }
}
