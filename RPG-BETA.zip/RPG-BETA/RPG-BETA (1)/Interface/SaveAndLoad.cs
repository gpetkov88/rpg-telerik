﻿using System;
using System.Linq;
using System.IO;
using System.Xml.Serialization;
namespace Interface
{
    public static class SaveAndLoad
    {
        public static void Save(Player player)
        {

            Stream stream = File.Open("Files/Save.xml", FileMode.Create);
            var xmlSerializer = new XmlSerializer(typeof(Player));
            xmlSerializer.Serialize(stream, player);
            stream.Close();
        }
        public static Player Load()
        {
            Stream stream = File.Open("Files/Save.xml", FileMode.Open);
            var xmlDeserializer = new XmlSerializer(typeof(Player));
            Player loadedPlayer = (Player)xmlDeserializer.Deserialize(stream);
            stream.Close();
            return loadedPlayer;
        }
    }
}