﻿namespace Interface
{
    partial class FormBattle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lifeBar1 = new System.Windows.Forms.ProgressBar();
            this.defVal1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.attVal1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lifeVal1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelName1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lifeBar2 = new System.Windows.Forms.ProgressBar();
            this.defVal2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.attVal2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lifeVal2 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.labelName2 = new System.Windows.Forms.Label();
            this.buttonHeal = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonHit = new System.Windows.Forms.Button();
            this.buttonWithdraw = new System.Windows.Forms.Button();
            this.buttonCharge = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.MenuText;
            this.richTextBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.richTextBox1.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.richTextBox1.Location = new System.Drawing.Point(366, 168);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(598, 488);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Liberation Serif", 40F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(568, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 60);
            this.label1.TabIndex = 1;
            this.label1.Text = "BATTLE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Liberation Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(223, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 53);
            this.label2.TabIndex = 2;
            this.label2.Text = "Allies";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Liberation Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(961, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(196, 53);
            this.label3.TabIndex = 3;
            this.label3.Text = "Enemies";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lifeBar1);
            this.panel1.Controls.Add(this.defVal1);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.attVal1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lifeVal1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.labelName1);
            this.panel1.Location = new System.Drawing.Point(212, 168);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(148, 160);
            this.panel1.TabIndex = 10;
            // 
            // lifeBar1
            // 
            this.lifeBar1.Location = new System.Drawing.Point(20, 47);
            this.lifeBar1.Name = "lifeBar1";
            this.lifeBar1.Size = new System.Drawing.Size(110, 23);
            this.lifeBar1.TabIndex = 7;
            // 
            // defVal1
            // 
            this.defVal1.AutoSize = true;
            this.defVal1.BackColor = System.Drawing.Color.Silver;
            this.defVal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.defVal1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.defVal1.Location = new System.Drawing.Point(89, 136);
            this.defVal1.Name = "defVal1";
            this.defVal1.Size = new System.Drawing.Size(17, 17);
            this.defVal1.TabIndex = 6;
            this.defVal1.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Silver;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(17, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "Defense:";
            // 
            // attVal1
            // 
            this.attVal1.AutoSize = true;
            this.attVal1.BackColor = System.Drawing.Color.DarkGray;
            this.attVal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.attVal1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.attVal1.Location = new System.Drawing.Point(89, 112);
            this.attVal1.Name = "attVal1";
            this.attVal1.Size = new System.Drawing.Size(17, 17);
            this.attVal1.TabIndex = 4;
            this.attVal1.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Silver;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(17, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "Attack:";
            // 
            // lifeVal1
            // 
            this.lifeVal1.AccessibleDescription = "";
            this.lifeVal1.AutoSize = true;
            this.lifeVal1.BackColor = System.Drawing.Color.DarkGray;
            this.lifeVal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lifeVal1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lifeVal1.Location = new System.Drawing.Point(89, 87);
            this.lifeVal1.Name = "lifeVal1";
            this.lifeVal1.Size = new System.Drawing.Size(17, 17);
            this.lifeVal1.TabIndex = 2;
            this.lifeVal1.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Silver;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(17, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Life:";
            // 
            // labelName1
            // 
            this.labelName1.AutoSize = true;
            this.labelName1.BackColor = System.Drawing.Color.Silver;
            this.labelName1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.labelName1.Location = new System.Drawing.Point(17, 21);
            this.labelName1.Name = "labelName1";
            this.labelName1.Size = new System.Drawing.Size(49, 17);
            this.labelName1.TabIndex = 0;
            this.labelName1.Text = "Name";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.lifeBar2);
            this.panel2.Controls.Add(this.defVal2);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.attVal2);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.lifeVal2);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.labelName2);
            this.panel2.Location = new System.Drawing.Point(970, 168);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(148, 160);
            this.panel2.TabIndex = 11;
            // 
            // lifeBar2
            // 
            this.lifeBar2.Location = new System.Drawing.Point(20, 47);
            this.lifeBar2.Name = "lifeBar2";
            this.lifeBar2.Size = new System.Drawing.Size(110, 23);
            this.lifeBar2.TabIndex = 7;
            // 
            // defVal2
            // 
            this.defVal2.AutoSize = true;
            this.defVal2.BackColor = System.Drawing.Color.Silver;
            this.defVal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.defVal2.ForeColor = System.Drawing.Color.DarkRed;
            this.defVal2.Location = new System.Drawing.Point(89, 136);
            this.defVal2.Name = "defVal2";
            this.defVal2.Size = new System.Drawing.Size(17, 17);
            this.defVal2.TabIndex = 6;
            this.defVal2.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Silver;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.DarkRed;
            this.label12.Location = new System.Drawing.Point(17, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 17);
            this.label12.TabIndex = 5;
            this.label12.Text = "Defense:";
            // 
            // attVal2
            // 
            this.attVal2.AutoSize = true;
            this.attVal2.BackColor = System.Drawing.Color.Silver;
            this.attVal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.attVal2.ForeColor = System.Drawing.Color.DarkRed;
            this.attVal2.Location = new System.Drawing.Point(89, 112);
            this.attVal2.Name = "attVal2";
            this.attVal2.Size = new System.Drawing.Size(17, 17);
            this.attVal2.TabIndex = 4;
            this.attVal2.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Silver;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.DarkRed;
            this.label14.Location = new System.Drawing.Point(17, 112);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 17);
            this.label14.TabIndex = 3;
            this.label14.Text = "Attack:";
            // 
            // lifeVal2
            // 
            this.lifeVal2.AutoSize = true;
            this.lifeVal2.BackColor = System.Drawing.Color.Silver;
            this.lifeVal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lifeVal2.ForeColor = System.Drawing.Color.DarkRed;
            this.lifeVal2.Location = new System.Drawing.Point(89, 87);
            this.lifeVal2.Name = "lifeVal2";
            this.lifeVal2.Size = new System.Drawing.Size(17, 17);
            this.lifeVal2.TabIndex = 2;
            this.lifeVal2.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Silver;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.DarkRed;
            this.label16.Location = new System.Drawing.Point(17, 87);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 17);
            this.label16.TabIndex = 1;
            this.label16.Text = "Life:";
            // 
            // labelName2
            // 
            this.labelName2.AutoSize = true;
            this.labelName2.BackColor = System.Drawing.Color.Silver;
            this.labelName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName2.ForeColor = System.Drawing.Color.DarkRed;
            this.labelName2.Location = new System.Drawing.Point(17, 21);
            this.labelName2.Name = "labelName2";
            this.labelName2.Size = new System.Drawing.Size(49, 17);
            this.labelName2.TabIndex = 0;
            this.labelName2.Text = "Name";
            // 
            // buttonHeal
            // 
            this.buttonHeal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonHeal.Location = new System.Drawing.Point(827, 115);
            this.buttonHeal.Name = "buttonHeal";
            this.buttonHeal.Size = new System.Drawing.Size(128, 37);
            this.buttonHeal.TabIndex = 16;
            this.buttonHeal.Text = "Heal";
            this.buttonHeal.UseVisualStyleBackColor = true;
            this.buttonHeal.Click += new System.EventHandler(this.buttonHeal_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(212, 334);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(148, 264);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Army";
            this.groupBox1.UseCompatibleTextRendering = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(970, 334);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(148, 264);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Foes";
            this.groupBox2.UseCompatibleTextRendering = true;
            // 
            // buttonHit
            // 
            this.buttonHit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonHit.Location = new System.Drawing.Point(366, 115);
            this.buttonHit.Name = "buttonHit";
            this.buttonHit.Size = new System.Drawing.Size(128, 37);
            this.buttonHit.TabIndex = 21;
            this.buttonHit.Text = "Hit";
            this.buttonHit.UseVisualStyleBackColor = true;
            this.buttonHit.Click += new System.EventHandler(this.ButtonHIT);
            // 
            // buttonWithdraw
            // 
            this.buttonWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonWithdraw.Location = new System.Drawing.Point(669, 115);
            this.buttonWithdraw.Name = "buttonWithdraw";
            this.buttonWithdraw.Size = new System.Drawing.Size(128, 37);
            this.buttonWithdraw.TabIndex = 22;
            this.buttonWithdraw.Text = "Withdraw";
            this.buttonWithdraw.UseVisualStyleBackColor = true;
            this.buttonWithdraw.Click += new System.EventHandler(this.buttonWithdraw_Click);
            // 
            // buttonCharge
            // 
            this.buttonCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCharge.Location = new System.Drawing.Point(519, 115);
            this.buttonCharge.Name = "buttonCharge";
            this.buttonCharge.Size = new System.Drawing.Size(128, 37);
            this.buttonCharge.TabIndex = 23;
            this.buttonCharge.Text = "Charge";
            this.buttonCharge.UseVisualStyleBackColor = true;
            this.buttonCharge.Click += new System.EventHandler(this.buttonCharge_Click);
            // 
            // FormBattle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1192, 598);
            this.Controls.Add(this.buttonCharge);
            this.Controls.Add(this.buttonWithdraw);
            this.Controls.Add(this.buttonHit);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonHeal);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox1);
            this.Name = "FormBattle";
            this.Text = "BATTLE";
            this.TransparencyKey = System.Drawing.Color.Transparent;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormBattle_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ProgressBar lifeBar1;
        private System.Windows.Forms.Label defVal1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label attVal1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lifeVal1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelName1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ProgressBar lifeBar2;
        private System.Windows.Forms.Label defVal2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label attVal2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lifeVal2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelName2;
        private System.Windows.Forms.Button buttonHeal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonHit;
        private System.Windows.Forms.Button buttonWithdraw;
        private System.Windows.Forms.Button buttonCharge;
    }
}