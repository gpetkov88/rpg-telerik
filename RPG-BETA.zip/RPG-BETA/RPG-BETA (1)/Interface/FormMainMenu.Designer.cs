﻿namespace Interface
{
    partial class FormMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMainMenu = new System.Windows.Forms.Label();
            this.bStart = new System.Windows.Forms.Button();
            this.bLoad = new System.Windows.Forms.Button();
            this.bOptions = new System.Windows.Forms.Button();
            this.bExit = new System.Windows.Forms.Button();
            this.cbMusicSwitch = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblMainMenu
            // 
            this.lblMainMenu.AutoSize = true;
            this.lblMainMenu.BackColor = System.Drawing.Color.Transparent;
            this.lblMainMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainMenu.Location = new System.Drawing.Point(519, 67);
            this.lblMainMenu.Name = "lblMainMenu";
            this.lblMainMenu.Size = new System.Drawing.Size(196, 39);
            this.lblMainMenu.TabIndex = 0;
            this.lblMainMenu.Text = "Main Menu";
            this.lblMainMenu.Click += new System.EventHandler(this.label1_Click);
            // 
            // bStart
            // 
            this.bStart.Location = new System.Drawing.Point(561, 188);
            this.bStart.Name = "bStart";
            this.bStart.Size = new System.Drawing.Size(107, 36);
            this.bStart.TabIndex = 1;
            this.bStart.Text = "START";
            this.bStart.UseVisualStyleBackColor = true;
            this.bStart.Click += new System.EventHandler(this.button1_Click);
            // 
            // bLoad
            // 
            this.bLoad.Location = new System.Drawing.Point(561, 243);
            this.bLoad.Name = "bLoad";
            this.bLoad.Size = new System.Drawing.Size(107, 36);
            this.bLoad.TabIndex = 2;
            this.bLoad.Text = "Load game";
            this.bLoad.UseVisualStyleBackColor = true;
            this.bLoad.Click += new System.EventHandler(this.button2_Click);
            // 
            // bOptions
            // 
            this.bOptions.Location = new System.Drawing.Point(561, 295);
            this.bOptions.Name = "bOptions";
            this.bOptions.Size = new System.Drawing.Size(107, 36);
            this.bOptions.TabIndex = 3;
            this.bOptions.Text = "Options";
            this.bOptions.UseVisualStyleBackColor = true;
            this.bOptions.Click += new System.EventHandler(this.button3_Click);
            // 
            // bExit
            // 
            this.bExit.Location = new System.Drawing.Point(561, 347);
            this.bExit.Name = "bExit";
            this.bExit.Size = new System.Drawing.Size(107, 36);
            this.bExit.TabIndex = 4;
            this.bExit.Text = "EXIT";
            this.bExit.UseVisualStyleBackColor = true;
            this.bExit.Click += new System.EventHandler(this.bFight_Click);
            // 
            // cbMusicSwitch
            // 
            this.cbMusicSwitch.Appearance = System.Windows.Forms.Appearance.Button;
            this.cbMusicSwitch.AutoSize = true;
            this.cbMusicSwitch.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cbMusicSwitch.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbMusicSwitch.Location = new System.Drawing.Point(13, 13);
            this.cbMusicSwitch.Name = "cbMusicSwitch";
            this.cbMusicSwitch.Size = new System.Drawing.Size(93, 24);
            this.cbMusicSwitch.TabIndex = 5;
            this.cbMusicSwitch.Text = "Music On / Off";
            this.cbMusicSwitch.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.cbMusicSwitch.UseVisualStyleBackColor = false;
            this.cbMusicSwitch.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // FormMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = global::Interface.Properties.Resources._3;
            this.ClientSize = new System.Drawing.Size(1118, 546);
            this.Controls.Add(this.cbMusicSwitch);
            this.Controls.Add(this.bExit);
            this.Controls.Add(this.bOptions);
            this.Controls.Add(this.bLoad);
            this.Controls.Add(this.bStart);
            this.Controls.Add(this.lblMainMenu);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "FormMainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hybrid";
            this.TransparencyKey = System.Drawing.Color.White;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMainMenu;
        private System.Windows.Forms.Button bStart;
        private System.Windows.Forms.Button bLoad;
        private System.Windows.Forms.Button bOptions;
        private System.Windows.Forms.Button bExit;
        private System.Windows.Forms.CheckBox cbMusicSwitch;

    }
}

