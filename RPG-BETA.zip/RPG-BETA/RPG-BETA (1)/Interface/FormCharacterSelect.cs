﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using WMPLib;

namespace Interface
{    
  
    public partial class FormCharacterSelect : Form
    {
        private WindowsMediaPlayer wplayer;

        public FormCharacterSelect(WindowsMediaPlayer wplayer)
        {
            InitializeComponent();
            //this.soundPlayer = soundPlayer;
            this.wplayer = wplayer;
            checkMage.Checked = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //FolderBrowserDialog d = new FolderBrowserDialog();
            //d.ShowDialog();
        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkKnight.Checked)
            {
                checkMage.Checked = false;
                checkArcher.Checked = false;
                checkAmazon.Checked = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            checkMage.Checked = true;
            if (checkMage.Checked)
            {
                checkKnight.Checked = false;
                checkArcher.Checked = false;
                checkAmazon.Checked = false;
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            checkKnight.Checked = true;
            if (checkKnight.Checked)
            {
                checkMage.Checked = false;
                checkArcher.Checked = false;
                checkAmazon.Checked = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkMage.Checked)
            {
                checkKnight.Checked = false;
                checkArcher.Checked = false;
                checkAmazon.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkArcher.Checked)
            {
                checkMage.Checked = false;
                checkKnight.Checked = false;
                checkAmazon.Checked = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            EHeroes playerProffesion = EHeroes.Sorcerer;
            var playerArmy = new List<Character>();

            List<Character> heroes = new List<Character>();
            heroes = FileManager.ReadCharacterList();
            Console.WriteLine(heroes.Count + "!!!");
            Character foundChar = new Character("Peasant", 50, 30, 30);


            // Check the labels
            if (checkMage.Checked == true)
            {
                playerProffesion = EHeroes.Sorcerer;
            }

            if (checkKnight.Checked == true)
            {
                playerProffesion = EHeroes.Knight;
            }

            if (checkAmazon.Checked == true)
            {
                playerProffesion = EHeroes.Amazon;
            }

            if (checkArcher.Checked == true)
            {
                playerProffesion = EHeroes.Archer;
            }


            if (name == "")
            {
                name = playerProffesion.ToString();
            }

            foreach (var hero in heroes)
            {
                if (hero.Name.ToUpper().Equals(playerProffesion.ToString().ToUpper()))
                {
                    foundChar = hero;
                }
                else
                {
                   // Console.WriteLine("Character not found in the Heroes.txt! ");
                    //playerArmy.Add(hero);
                }
            }


            Player player1 = new Player(name, playerProffesion, foundChar, playerArmy);
            player1.Hero.Name = name;
            wplayer.controls.stop();

            FormAdventure f3 = new FormAdventure(player1);
            f3.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            checkArcher.Checked = true;
            if (checkArcher.Checked)
            {
                checkMage.Checked = false;
                checkKnight.Checked = false;
                checkAmazon.Checked = false;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            
            if (checkAmazon.Checked)
            {
                checkMage.Checked = false;
                checkKnight.Checked = false;
                checkArcher.Checked = false;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            checkAmazon.Checked = true;
            if (checkArcher.Checked)
            {
                checkMage.Checked = false;
                checkKnight.Checked = false;
                checkArcher.Checked = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            checkMage.BackColor = Color.DarkGray;
            if (checkMage.Checked)
            {
                //checkBox1.Text = "Music Off";
                wplayer.controls.play();
                
            }
            else
            {
                //checkBox1.Text = "Music On";
                wplayer.controls.stop();
                
            }
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
