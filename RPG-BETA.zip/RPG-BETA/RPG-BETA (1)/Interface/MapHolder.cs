﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Interface
{
    public class MapHolder
    {
        private Point startPosition = new Point(50, 50);
        private const int Step = 55;

        public static readonly int[,] Map = new int[,]
        {
            {9,9,1,1,1,0,0,0,0,0,1,0,0,0,0,0},
            {9,9,9,0,1,0,0,0,0,0,1,0,0,0,0,0},
            {0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0},
            {0,0,0,0,1,0,0,0,0,0,1,0,1,1,1,1},
            {0,0,0,0,1,0,0,0,0,0,1,0,1,0,0,1},
            {9,9,9,0,2,1,1,1,1,2,2,1,1,0,0,1},
            {1,9,9,0,1,0,0,0,0,1,0,0,0,0,0,1},
            {1,0,0,1,1,0,0,0,0,1,0,0,0,0,0,1},
            {1,0,0,1,0,0,0,0,0,1,3,3,3,3,3,2},
            {1,0,1,2,1,1,1,1,1,2,3,1,1,1,1,1},
            {1,0,1,0,0,0,0,0,0,2,3,0,0,0,0,0},
            {1,1,2,1,1,1,1,1,1,2,1,1,1,1,1,1},
        };

        public List<Field> CalculateMove(Field StartSquare, int steps, int direction)
        {
            List<Field> result = new List<Field>();

            // 

            return result;
        }
    }
}
