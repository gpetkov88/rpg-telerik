﻿using System;
using System.Linq;

namespace Interface
{
    public enum EHeroes
    {
        Amazon,
        Archer,
        Knight,
        Sorcerer

    }
}
