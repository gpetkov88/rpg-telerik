﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    public class Creature
    {
        public Creature(string name, int hp, int atack, int defense)
        {
            this.Name = name;
            this.IsAlive = true;
            this.Health = hp;
            this.Attack = atack;
            this.Defense = defense;
            this.MaxHP = hp;
            log = new List<string>();
        }

        public List<string> log { get; set; }

        public string Name { get; set; }

        public string Status { get; set; }

        public bool IsAlive { get; set; }

        public int Attack { get; set; }
        public int Defense { get; set; }
        public int Health { get; set; }
        public int MaxHP { get; set; }

        public int Rank { get; set; }

    }
}
